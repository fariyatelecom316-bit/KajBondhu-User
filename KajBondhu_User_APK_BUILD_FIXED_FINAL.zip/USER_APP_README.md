# কাজবন্ধু — User App

এটি শুধুমাত্র Customer/Worker ব্যবহারকারীদের জন্য। Admin dashboard এই অ্যাপে নেই।

- Google Login
- Customer/Worker mode
- Worker profiles
- Job posting/acceptance
- Chat
- AI assistant
- Wallet UI
- Firebase/Firestore realtime sync
- bKash/Nagad/Rocket backend integration files

Admin আলাদা অ্যাপে থাকবে: `KajBondhu-Admin`।
