# KajBondhu Online-Ready Update

- Google/Firebase authentication retained; phone OTP removed.
- Worker profiles are owned by Firebase UID; cross-user editing is blocked.
- Worker/job data is synchronized with Firestore listeners after authentication.
- Jobs now carry `assignedWorkerUid` so worker acceptance/status updates can be authorized securely.
- Job and new worker local IDs use millisecond timestamps to reduce cross-device Room ID collisions.
- Chat messages carry `senderUid` and sync through Firestore under each job.
- Added Room migration 4 -> 5 for `assignedWorkerUid` and `senderUid`.
- Removed the hard-coded fallback phone number from booking calls.
- Added Android INTERNET permission.
- Wallet does not create fake/demo money; real balance changes remain blocked until verified gateway integration.
- bKash/Nagad/Rocket backend remains server-side and requires merchant credentials + HTTPS deployment later.

Build note: this environment does not have Gradle installed and the source ZIP did not contain gradle-wrapper.jar, so a full APK build could not be executed here. Android Studio/Google AI Studio should sync the declared Gradle wrapper distribution online; if it asks to regenerate the wrapper, use the declared Gradle version in `gradle-wrapper.properties`.
