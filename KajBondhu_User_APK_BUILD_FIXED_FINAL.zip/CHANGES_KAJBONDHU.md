# KajBondhu cleanup and authentication update

## Implemented
- Removed runtime demo/sample seeding: workers, jobs, wallet transactions, and chat messages are no longer inserted by `SeedData`/repository startup.
- Added Room migration 3 -> 4 to remove the known legacy seed/demo records from older local installs while preserving unrelated records.
- Added `ownerUid` to wallet transactions and scoped wallet history to the authenticated Firebase UID.
- Fake wallet recharge/cash-out no longer changes the wallet balance. The UI now clearly states that verified payment is required.
- Removed Guest/Skip Login from the login UI and authentication flow.
- Added Google Account sign-in using Android Credential Manager + Firebase Google authentication.
- Kept Phone OTP available as a legacy/fallback login method.
- Worker profile editing is restricted to the authenticated user's `ownerUid` in the app logic; an existing profile with another owner cannot be updated.
- Worker profile matching no longer uses phone-number matching; authenticated UID is the ownership key.
- Added `ownerUid` to job records and Firestore synchronization.
- Added `firestore.rules` with UID-based ownership protection for users, workers, and job posts.
- Replaced `app/google-services.json` with the newly downloaded Firebase configuration supplied for this project.

## Important
- Real bKash/Nagad gateway verification is not implemented by this change. No fake money is credited anymore. A real payment backend/gateway must be connected before enabling actual deposits/withdrawals.
- Firestore rules must be deployed in Firebase Console/CLI before production use.
- The uploaded project did not contain `gradlew`, and no system Gradle installation was available in this environment, so a full Android Gradle build could not be executed here. Static source checks were performed.
