# কাজবন্ধু User App — Online Completion Checklist

## ইতিমধ্যে ঠিক করা হয়েছে
- Google/Firebase Authentication (phone OTP বাদ)
- Firebase UID দিয়ে profile ownership security
- Firestore realtime workers/jobs
- Worker job acceptance with assignedWorkerUid
- Job owner/assigned worker status security
- Firestore realtime job chat
- Chat message sender UID security
- User profile Firestore sync (name/email/role/phone)
- User mode persistence (CLIENT/WORKER)
- INTERNET permission
- Demo wallet money disabled
- bKash/Nagad/Rocket server adapter প্রস্তুত

## এখন Firebase Console-এ একবার করতে হবে
1. Authentication > Sign-in method > Google Enabled রাখুন।
2. Firestore Database চালু রাখুন।
3. এই project's `firestore.rules` deploy করুন।
4. `admins/{ADMIN_FIREBASE_UID}` document তৈরি করুন:
   - `enabled: true`
   - `role: "ADMIN"`
5. Google sign-in test করুন।

## Payment চালু করার আগে
1. bKash merchant/PRA gateway credentials নিন।
2. Nagad merchant gateway credentials নিন।
3. Rocket/DBBL merchant gateway integration pack নিন।
4. `payment-backend/.env` পূরণ করুন।
5. Backend HTTPS domain-এ deploy করুন।
6. Android app-এ backend base URL বসিয়ে payment UI connect করুন।
7. Sandbox transaction test করুন।
8. Verified callback/ledger balance না হওয়া পর্যন্ত wallet-এ টাকা যোগ হবে না।

## Build
এই ZIP-এ source সম্পূর্ণ করা হয়েছে, কিন্তু local environment-এ Gradle wrapper JAR না থাকায় এখানে Android APK compile করা সম্ভব হয়নি। Android Studio/Google AI Studio-তে project খুলে Gradle Sync চালান।
