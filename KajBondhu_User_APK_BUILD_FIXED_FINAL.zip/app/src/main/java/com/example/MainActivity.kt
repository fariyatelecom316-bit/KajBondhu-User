package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.data.model.JobRequestEntity
import com.example.data.model.WorkerEntity
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.AuthViewModel
import com.example.ui.components.BottomModeSwitcher
import com.example.ui.components.KajBondhuBottomBar
import com.example.ui.components.KajBondhuTopBar
import com.example.ui.dialogs.BookWorkerDirectDialog
import com.example.ui.dialogs.ChatDialog
import com.example.ui.dialogs.ClientProfileDialog
import com.example.ui.dialogs.EditWorkerProfileDialog
import com.example.ui.dialogs.LocationPickerDialog
import com.example.ui.dialogs.PostJobDialog
import com.example.ui.dialogs.ReviewJobDialog
import com.example.ui.dialogs.WorkerDetailDialog
import com.example.ui.screens.AiChatScreen
import com.example.ui.screens.BookingsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.screens.WorkersScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.KajBondhuViewModel
import com.example.ui.viewmodel.UserMode

class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by viewModels()
    private val appViewModel: KajBondhuViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KajBondhuApp(
                    authViewModel = authViewModel,
                    viewModel = appViewModel,
                    activity = this
                )
            }
        }
    }
}

@Composable
fun KajBondhuApp(
    authViewModel: AuthViewModel,
    viewModel: KajBondhuViewModel,
    activity: ComponentActivity
) {
    val authUiState by authViewModel.uiState.collectAsState()

    if (!authUiState.isAuthenticated) {
        AuthScreen(
            uiState = authUiState,
            onGoogleSignIn = { authViewModel.signInWithGoogle(activity) },
        )
    } else {
        MainAppContent(
            authViewModel = authViewModel,
            viewModel = viewModel
        )
    }
}

@Composable
fun MainAppContent(
    authViewModel: AuthViewModel,
    viewModel: KajBondhuViewModel
) {
    val authUiState by authViewModel.uiState.collectAsState()
    val userMode by viewModel.userMode.collectAsState()
    val currentLocation by viewModel.currentLocation.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val allWorkers by viewModel.allWorkers.collectAsState()
    val filteredWorkers by viewModel.filteredWorkers.collectAsState()
    val jobs by viewModel.jobs.collectAsState()
    val walletTransactions by viewModel.walletTransactions.collectAsState()
    val currentWorkerProfile by viewModel.currentWorkerProfile.collectAsState()
    val aiMessages by viewModel.aiMessages.collectAsState()
    val isAiGenerating by viewModel.isAiGenerating.collectAsState()
    val currentJobChatMessages by viewModel.currentJobChatMessages.collectAsState()
    val paymentMessage by viewModel.paymentMessage.collectAsState()
    val searchQuery by viewModel.workerSearchQuery.collectAsState()
    val selectedCatId by viewModel.selectedCategoryId.collectAsState()

    // Sync worker profile with authenticated user
    LaunchedEffect(authUiState.currentUserUid, authUiState.userPhoneNumber, authUiState.displayName, authUiState.email) {
        viewModel.syncWorkerWithAuth(authUiState.currentUserUid, authUiState.userPhoneNumber, authUiState.displayName, authUiState.email)
    }

    var currentTab by remember { mutableStateOf(AppNavTab.HOME) }

    // Dialogs & Modals state
    var showPostJobDialog by remember { mutableStateOf(false) }
    var showLocationPicker by remember { mutableStateOf(false) }
    var selectedWorkerForDetail by remember { mutableStateOf<WorkerEntity?>(null) }
    var selectedWorkerForBooking by remember { mutableStateOf<WorkerEntity?>(null) }
    var activeJobForChat by remember { mutableStateOf<JobRequestEntity?>(null) }
    var activeJobForReview by remember { mutableStateOf<JobRequestEntity?>(null) }
    var workerToEdit by remember { mutableStateOf<WorkerEntity?>(null) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showClientProfileDialog by remember { mutableStateOf(false) }

    val activeBookingsCount = jobs.count { it.status == "IN_PROGRESS" || it.status == "ACCEPTED" }

    Scaffold(
        topBar = {
            Column {
                KajBondhuTopBar(
                    userMode = userMode,
                    currentLocation = currentLocation,
                    onLocationClick = { showLocationPicker = true },
                    onProfileClick = {
                        if (userMode == UserMode.CLIENT) {
                            showClientProfileDialog = true
                        } else {
                            currentTab = AppNavTab.PROFILE
                        }
                    },
                    onSwitchModeClick = {
                        val newMode = if (userMode == UserMode.CLIENT) UserMode.WORKER else UserMode.CLIENT
                        viewModel.setUserMode(newMode)
                    },
                    onPostJobClick = { showPostJobDialog = true }
                )
                BottomModeSwitcher(
                    userMode = userMode,
                    onModeChange = { newMode -> viewModel.setUserMode(newMode) }
                )
            }
        },
        bottomBar = {
            KajBondhuBottomBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it },
                activeBookingsCount = activeBookingsCount
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppNavTab.HOME -> {
                    HomeScreen(
                        userMode = userMode,
                        categories = categories,
                        workers = allWorkers,
                        activeJobs = jobs,
                        searchQuery = searchQuery,
                        onSearchChange = { viewModel.setWorkerSearchQuery(it) },
                        onCategoryClick = { cat ->
                            viewModel.setSelectedCategoryId(cat.id)
                            currentTab = AppNavTab.WORKERS
                        },
                        onWorkerClick = { worker ->
                            selectedWorkerForDetail = worker
                        },
                        onPostJobClick = { showPostJobDialog = true },
                        onViewAllWorkers = {
                            viewModel.setSelectedCategoryId(null)
                            currentTab = AppNavTab.WORKERS
                        },
                        onOpenAiChat = { currentTab = AppNavTab.AI_CHAT },
                        onAcceptJobAsWorker = { job ->
                            viewModel.acceptJobAsWorker(job)
                            currentTab = AppNavTab.BOOKINGS
                        },
                        onJobClick = { job ->
                            activeJobForChat = job
                            viewModel.loadChatMessages(job.id)
                        }
                    )
                }

                AppNavTab.WORKERS -> {
                    WorkersScreen(
                        workers = filteredWorkers,
                        categories = categories,
                        selectedCategoryId = selectedCatId,
                        searchQuery = searchQuery,
                        onSearchChange = { viewModel.setWorkerSearchQuery(it) },
                        onCategorySelect = { catId -> viewModel.setSelectedCategoryId(catId) },
                        onWorkerClick = { worker ->
                            selectedWorkerForDetail = worker
                        },
                        onAddWorkerClick = if (userMode == UserMode.WORKER) {
                            {
                                val newWorker = WorkerEntity(
                                    nameBn = "",
                                    nameEn = "",
                                    categoryId = "electrician",
                                    categoryTitleBn = "ইলেকট্রিশিয়ান",
                                    phone = authUiState.userPhoneNumber.ifBlank { "" },
                                    area = currentLocation,
                                    experienceYears = 3,
                                    hourlyRate = 400,
                                    rating = 5.0f,
                                    reviewsCount = 0,
                                    completedJobsCount = 0,
                                    bioBn = "",
                                    skillsBn = "",
                                    ownerUid = authUiState.currentUserUid
                                )
                                workerToEdit = newWorker
                                showEditProfileDialog = true
                            }
                        } else null
                    )
                }

                AppNavTab.BOOKINGS -> {
                    BookingsScreen(
                        userMode = userMode,
                        jobs = jobs,
                        onOpenChat = { job ->
                            activeJobForChat = job
                            viewModel.loadChatMessages(job.id)
                        },
                        onStatusChange = { jobId, status ->
                            viewModel.updateJobStatus(jobId, status)
                        },
                        onReviewClick = { job ->
                            activeJobForReview = job
                        }
                    )
                }

                AppNavTab.WALLET -> {
                    WalletScreen(
                        userMode = userMode,
                        transactions = walletTransactions,
                        onAddMoney = { amount, method ->
                            viewModel.addWalletMoney(amount, method) { url ->
                                runCatching {
                                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                                    activity.startActivity(intent)
                                }.onFailure { viewModel.clearPaymentMessage() }
                            }
                        },
                        onWithdrawMoney = { amount, method -> viewModel.withdrawWalletMoney(amount, method) },
                        paymentMessage = paymentMessage,
                        onClearPaymentMessage = viewModel::clearPaymentMessage,
                        onVerifyPendingBkash = viewModel::verifyPendingBkash,
                        onRefresh = { },
                        onBackClick = { currentTab = AppNavTab.PROFILE }
                    )
                }

                AppNavTab.AI_CHAT -> {
                    AiChatScreen(
                        userMode = userMode,
                        messages = aiMessages,
                        isGenerating = isAiGenerating,
                        onSendMessage = { prompt -> viewModel.sendAiChatMessage(prompt) },
                        onClearChat = { viewModel.clearAiChat() }
                    )
                }

                AppNavTab.PROFILE -> {
                    ProfileScreen(
                        authUiState = authUiState,
                        userMode = userMode,
                        currentWorkerProfile = currentWorkerProfile,
                        currentLocation = currentLocation,
                        onToggleMode = {
                            val newMode = if (userMode == UserMode.CLIENT) UserMode.WORKER else UserMode.CLIENT
                            viewModel.setUserMode(newMode)
                        },
                        onEditWorkerProfile = { worker ->
                            workerToEdit = worker
                            showEditProfileDialog = true
                        },
                        onRegisterAsWorker = {
                            val newWorker = WorkerEntity(
                                nameBn = "",
                                nameEn = "",
                                categoryId = "electrician",
                                categoryTitleBn = "ইলেকট্রিশিয়ান",
                                phone = authUiState.userPhoneNumber.ifBlank { "" },
                                area = currentLocation,
                                experienceYears = 3,
                                hourlyRate = 400,
                                rating = 5.0f,
                                reviewsCount = 0,
                                completedJobsCount = 0,
                                bioBn = "",
                                skillsBn = "",
                                ownerUid = authUiState.currentUserUid
                            )
                            workerToEdit = newWorker
                            showEditProfileDialog = true
                        },
                        onOpenWallet = { currentTab = AppNavTab.WALLET },
                        onSignOut = { authViewModel.signOut() }
                    )
                }
            }
        }
    }

    // Post Job Dialog
    if (showPostJobDialog) {
        PostJobDialog(
            categories = categories,
            initialCategoryId = selectedCatId,
            currentLocation = currentLocation,
            onDismiss = { showPostJobDialog = false },
            onSubmit = { title, catId, desc, address, budget, urgent, date, time ->
                viewModel.postNewJob(
                    title = title,
                    categoryId = catId,
                    description = desc,
                    address = address,
                    budget = budget,
                    isUrgent = urgent,
                    scheduledDate = date,
                    scheduledTime = time,
                    clientPhone = authUiState.userPhoneNumber.ifBlank { "" }
                )
                showPostJobDialog = false
                currentTab = AppNavTab.BOOKINGS
            }
        )
    }

    // Direct Booking Dialog
    selectedWorkerForBooking?.let { worker ->
        BookWorkerDirectDialog(
            worker = worker,
            currentLocation = currentLocation,
            onDismiss = { selectedWorkerForBooking = null },
            onConfirm = { title, desc, address, budget ->
                viewModel.bookWorkerDirect(
                    worker = worker,
                    title = title,
                    description = desc,
                    address = address,
                    budget = budget,
                    clientPhone = authUiState.userPhoneNumber.ifBlank { "" }
                )
                selectedWorkerForBooking = null
                currentTab = AppNavTab.BOOKINGS
            }
        )
    }

    // Worker Detail Dialog
    selectedWorkerForDetail?.let { worker ->
        WorkerDetailDialog(
            worker = worker,
            onDismiss = { selectedWorkerForDetail = null },
            onBookClick = {
                selectedWorkerForBooking = worker
            },
            onEditClick = if (userMode == UserMode.WORKER && worker.ownerUid == authUiState.currentUserUid) {
                {
                    selectedWorkerForDetail = null
                    workerToEdit = worker
                    showEditProfileDialog = true
                }
            } else null,
            onWalletClick = {
                selectedWorkerForDetail = null
                currentTab = AppNavTab.WALLET
            }
        )
    }

    // Edit Worker Profile Dialog
    if (showEditProfileDialog && workerToEdit != null) {
        EditWorkerProfileDialog(
            worker = workerToEdit!!,
            categories = categories,
            onDismiss = {
                showEditProfileDialog = false
                workerToEdit = null
            },
            onSave = { updatedWorker ->
                viewModel.saveWorkerProfile(updatedWorker, currentUid = authUiState.currentUserUid)
                showEditProfileDialog = false
                workerToEdit = null
            }
        )
    }

    // Location Picker Dialog
    if (showLocationPicker) {
        LocationPickerDialog(
            currentLocation = currentLocation,
            onDismiss = { showLocationPicker = false },
            onSelectLocation = { newLoc ->
                viewModel.setCurrentLocation(newLoc)
                showLocationPicker = false
            }
        )
    }

    // Chat Dialog
    activeJobForChat?.let { job ->
        ChatDialog(
            job = job,
            messages = currentJobChatMessages,
            onDismiss = { activeJobForChat = null },
            onSendMessage = { text ->
                val isClient = userMode == UserMode.CLIENT
                val sender = if (isClient) "গ্রাহক" else (job.assignedWorkerName ?: "কারিগর")
                viewModel.sendChatMessage(job.id, text, isClient, sender)
            }
        )
    }

    // Review Dialog
    activeJobForReview?.let { job ->
        ReviewJobDialog(
            job = job,
            onDismiss = { activeJobForReview = null },
            onSubmit = { rating, reviewText ->
                viewModel.submitJobReview(job.id, job.assignedWorkerId, rating, reviewText)
                activeJobForReview = null
            }
        )
    }

    // Client Profile Dialog
    if (showClientProfileDialog) {
        val completedCount = jobs.count { it.status == "COMPLETED" }
        ClientProfileDialog(
            userLocation = currentLocation,
            completedJobsCount = completedCount,
            onDismiss = { showClientProfileDialog = false },
            onWalletClick = {
                showClientProfileDialog = false
                currentTab = AppNavTab.WALLET
            },
            onPostJobClick = {
                showClientProfileDialog = false
                showPostJobDialog = true
            }
        )
    }
}
