package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JobRequestEntity
import com.example.ui.components.StatusBadge
import com.example.ui.components.dialPhoneNumber
import com.example.ui.theme.StarGold
import com.example.ui.viewmodel.UserMode

@Composable
fun BookingsScreen(
    userMode: UserMode,
    jobs: List<JobRequestEntity>,
    onOpenChat: (JobRequestEntity) -> Unit,
    onStatusChange: (Long, String) -> Unit,
    onReviewClick: (JobRequestEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedFilterIndex by remember { mutableStateOf(0) }
    val tabs = listOf("সকল কাজ", "চলমান", "পেন্ডিং", "সম্পন্ন")

    val filteredJobs = when (selectedFilterIndex) {
        1 -> jobs.filter { it.status == "IN_PROGRESS" || it.status == "ACCEPTED" }
        2 -> jobs.filter { it.status == "PENDING" }
        3 -> jobs.filter { it.status == "COMPLETED" }
        else -> jobs
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("bookings_screen")
    ) {
        // Tab Filter Row
        TabRow(
            selectedTabIndex = selectedFilterIndex,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            tabs.forEachIndexed { index, tabTitle ->
                Tab(
                    selected = selectedFilterIndex == index,
                    onClick = { selectedFilterIndex = index },
                    text = {
                        Text(
                            text = tabTitle,
                            fontWeight = if (selectedFilterIndex == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        if (filteredJobs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "এই তালিকায় কোনো কাজ বা বুকিং নেই",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "নতুন কাজের জন্য হোমে গিয়ে বিজ্ঞপ্তি দিন বা কারিগর নির্বাচন করুন।",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredJobs) { job ->
                    BookingJobCard(
                        job = job,
                        userMode = userMode,
                        onOpenChat = { onOpenChat(job) },
                        onCall = {
                            val phoneToCall = if (userMode == UserMode.CLIENT)
                                job.assignedWorkerPhone.orEmpty()
                            else
                                job.clientPhone
                            dialPhoneNumber(context, phoneToCall)
                        },
                        onStartJob = { onStatusChange(job.id, "IN_PROGRESS") },
                        onCompleteJob = { onStatusChange(job.id, "COMPLETED") },
                        onCancelJob = { onStatusChange(job.id, "CANCELLED") },
                        onReviewClick = { onReviewClick(job) }
                    )
                }
            }
        }
    }
}

@Composable
fun BookingJobCard(
    job: JobRequestEntity,
    userMode: UserMode,
    onOpenChat: () -> Unit,
    onCall: () -> Unit,
    onStartJob: () -> Unit,
    onCompleteJob: () -> Unit,
    onCancelJob: () -> Unit,
    onReviewClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.5.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("booking_job_card_${job.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Category, Status, Budget
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(status = job.status)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = job.categoryTitleBn,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
                Text(
                    text = "৳${job.budget}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0A6847)
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Job Title
            Text(
                text = job.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            // Job Description
            if (job.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = job.description,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Location & Schedule
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = job.address,
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${job.scheduledDate}, ${job.scheduledTime}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Assigned Person Info (Worker or Client)
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (userMode == UserMode.CLIENT)
                                "কারিগর: ${job.assignedWorkerName ?: "অপেক্ষমান..."}"
                            else
                                "গ্রাহক: ${job.clientName}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = if (userMode == UserMode.CLIENT)
                                (job.assignedWorkerPhone ?: "শীঘ্রই এসাইন করা হবে")
                            else
                                job.clientPhone,
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                        )
                    }

                    // Chat & Call buttons if worker assigned
                    if (job.assignedWorkerName != null) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = onOpenChat, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.Chat, contentDescription = "চ্যাট", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            }
                            IconButton(onClick = onCall, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.Call, contentDescription = "কল", tint = Color(0xFF16A34A), modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }

            // Review Display if completed and reviewed
            if (job.ratingGiven > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF3C7),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = StarGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${job.ratingGiven}★ - \"${job.reviewGiven}\"",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF78350F)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons based on status & role
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (job.status) {
                    "PENDING" -> {
                        OutlinedButton(
                            onClick = onCancelJob,
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("বাতিল করুন", fontSize = 12.sp)
                        }
                    }
                    "ACCEPTED" -> {
                        Button(
                            onClick = onStartJob,
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("কাজ শুরু হয়েছে", fontSize = 12.sp)
                        }
                    }
                    "IN_PROGRESS" -> {
                        Button(
                            onClick = onCompleteJob,
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("কাজ সম্পন্ন চিহ্নিত করুন", fontSize = 12.sp)
                        }
                    }
                    "COMPLETED" -> {
                        if (userMode == UserMode.CLIENT && job.ratingGiven == 0) {
                            Button(
                                onClick = onReviewClick,
                                modifier = Modifier.weight(1f).height(38.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StarGold)
                            ) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("রিভিউ দিন", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
