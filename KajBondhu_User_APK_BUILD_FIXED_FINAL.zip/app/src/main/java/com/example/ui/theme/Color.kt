package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KajBondhu Emerald & Gold Palette
val EmeraldPrimary = Color(0xFF0A6847)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFD1FAE5)
val EmeraldOnPrimaryContainer = Color(0xFF064E3B)

val AmberSecondary = Color(0xFFD97706)
val AmberOnSecondary = Color(0xFFFFFFFF)
val AmberSecondaryContainer = Color(0xFFFEF3C7)
val AmberOnSecondaryContainer = Color(0xFF78350F)

val SlateTertiary = Color(0xFF2563EB)
val SlateOnTertiary = Color(0xFFFFFFFF)
val SlateTertiaryContainer = Color(0xFFDBEAFE)
val SlateOnTertiaryContainer = Color(0xFF1E3A8A)

val NeutralBackground = Color(0xFFF8FAFC)
val NeutralSurface = Color(0xFFFFFFFF)
val NeutralSurfaceVariant = Color(0xFFF1F5F9)
val NeutralOnSurface = Color(0xFF0F172A)
val NeutralOnSurfaceVariant = Color(0xFF475569)
val NeutralOutline = Color(0xFFCBD5E1)

val ErrorRed = Color(0xFFDC2626)
val SuccessGreen = Color(0xFF16A34A)
val StarGold = Color(0xFFFBBF24)
val UrgentRed = Color(0xFFEF4444)

// Dark Theme Colors
val EmeraldPrimaryDark = Color(0xFF34D399)
val EmeraldOnPrimaryDark = Color(0xFF064E3B)
val EmeraldContainerDark = Color(0xFF065F46)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkOnSurface = Color(0xFFF8FAFC)
