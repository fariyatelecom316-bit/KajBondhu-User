package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.StarGold
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.UrgentRed
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.UserMode

fun dialPhoneNumber(context: Context, phoneNumber: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$phoneNumber")
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "ফোন নম্বর ডায়াল করতে সমস্যা: $phoneNumber", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KajBondhuTopAppBar(
    location: String,
    userMode: UserMode,
    onLocationClick: () -> Unit,
    onToggleMode: () -> Unit,
    onPostJobClick: () -> Unit,
    modifier: Modifier = Modifier,
    onProfileClick: (() -> Unit)? = null
) {
    Surface(
        color = MaterialTheme.colorScheme.primary,
        shadowElevation = 3.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Logo & Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🤝",
                            fontSize = 20.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "কাজবন্ধু",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        // Clickable location badge
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onLocationClick() }
                                .padding(vertical = 1.dp)
                                .testTag("location_selector_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "স্থান",
                                tint = MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = location,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 11.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Mode switch badge
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (userMode == UserMode.CLIENT)
                            Color(0xFFFEF3C7) // Amber container
                        else
                            Color(0xFFDBEAFE), // Blue container
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { onToggleMode() }
                            .testTag("mode_toggle_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "মোড বদলান",
                                tint = if (userMode == UserMode.CLIENT) Color(0xFFB45309) else Color(0xFF1E40AF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (userMode == UserMode.CLIENT) "গ্রাহক মোড" else "কারিগর মোড",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (userMode == UserMode.CLIENT) Color(0xFF92400E) else Color(0xFF1E3A8A)
                                )
                            )
                        }
                    }

                    // Profile Icon Button
                    if (onProfileClick != null) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .clickable { onProfileClick() }
                                .testTag("top_bar_profile_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "প্রোফাইল",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KajBondhuTopBar(
    userMode: UserMode,
    currentLocation: String,
    onLocationClick: () -> Unit,
    onProfileClick: () -> Unit,
    onSwitchModeClick: () -> Unit,
    onPostJobClick: () -> Unit = {}
) {
    KajBondhuTopAppBar(
        location = currentLocation,
        userMode = userMode,
        onLocationClick = onLocationClick,
        onToggleMode = onSwitchModeClick,
        onPostJobClick = onPostJobClick,
        onProfileClick = onProfileClick
    )
}

@Composable
fun BottomModeSwitcher(
    userMode: UserMode,
    onModeChange: (UserMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isClient = userMode == UserMode.CLIENT
                    // Client Mode Option
                    Surface(
                        onClick = { onModeChange(UserMode.CLIENT) },
                        shape = RoundedCornerShape(18.dp),
                        color = if (isClient) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (isClient) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("bottom_mode_client")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "গ্রাহক মোড",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "গ্রাহক মোড",
                                fontSize = 12.sp,
                                fontWeight = if (isClient) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    val isWorker = userMode == UserMode.WORKER
                    // Worker Mode Option
                    Surface(
                        onClick = { onModeChange(UserMode.WORKER) },
                        shape = RoundedCornerShape(18.dp),
                        color = if (isWorker) Color(0xFF1E40AF) else Color.Transparent,
                        contentColor = if (isWorker) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("bottom_mode_worker")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Engineering,
                                contentDescription = "কারিগর মোড",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "কারিগর মোড",
                                fontSize = 12.sp,
                                fontWeight = if (isWorker) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KajBondhuBottomBar(
    currentTab: AppNavTab,
    onTabSelected: (AppNavTab) -> Unit,
    activeBookingsCount: Int = 0,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = modifier.testTag("main_bottom_nav_bar")
    ) {
        NavigationBarItem(
            selected = currentTab == AppNavTab.HOME,
            onClick = { onTabSelected(AppNavTab.HOME) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "হোম"
                )
            },
            label = {
                Text(
                    text = "হোম",
                    fontSize = 11.sp,
                    fontWeight = if (currentTab == AppNavTab.HOME) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.testTag("tab_home")
        )

        NavigationBarItem(
            selected = currentTab == AppNavTab.WORKERS,
            onClick = { onTabSelected(AppNavTab.WORKERS) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "কারিগরবৃন্দ"
                )
            },
            label = {
                Text(
                    text = "কারিগরবৃন্দ",
                    fontSize = 11.sp,
                    fontWeight = if (currentTab == AppNavTab.WORKERS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.testTag("tab_workers")
        )

        NavigationBarItem(
            selected = currentTab == AppNavTab.AI_CHAT,
            onClick = { onTabSelected(AppNavTab.AI_CHAT) },
            icon = {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI সহকারী"
                )
            },
            label = {
                Text(
                    text = "AI সহকারী",
                    fontSize = 11.sp,
                    fontWeight = if (currentTab == AppNavTab.AI_CHAT) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.testTag("tab_ai_chat")
        )

        NavigationBarItem(
            selected = currentTab == AppNavTab.BOOKINGS,
            onClick = { onTabSelected(AppNavTab.BOOKINGS) },
            icon = {
                if (activeBookingsCount > 0) {
                    BadgedBox(
                        badge = {
                            Badge(
                                containerColor = UrgentRed,
                                contentColor = Color.White
                            ) {
                                Text("$activeBookingsCount")
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.BusinessCenter,
                            contentDescription = "বুকিং"
                        )
                    }
                } else {
                    Icon(
                        imageVector = Icons.Default.BusinessCenter,
                        contentDescription = "বুকিং"
                    )
                }
            },
            label = {
                Text(
                    text = "বুকিং",
                    fontSize = 11.sp,
                    fontWeight = if (currentTab == AppNavTab.BOOKINGS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.testTag("tab_bookings")
        )
    }
}

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (textBn, bgColor, textColor) = when (status) {
        "PENDING" -> Triple("অপেক্ষমান", Color(0xFFFEF3C7), Color(0xFFB45309))
        "ACCEPTED" -> Triple("গৃহীত", Color(0xFFDBEAFE), Color(0xFF1D4ED8))
        "IN_PROGRESS" -> Triple("চলমান", Color(0xFFE0E7FF), Color(0xFF4338CA))
        "COMPLETED" -> Triple("সম্পন্ন", Color(0xFFDCFCE7), Color(0xFF15803D))
        "CANCELLED" -> Triple("বাতিল", Color(0xFFFEE2E2), Color(0xFFB91C1C))
        else -> Triple(status, Color(0xFFF1F5F9), Color(0xFF475569))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = textBn,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = textColor,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
fun RatingBarDisplay(
    rating: Float,
    reviewsCount: Int? = null,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        Icon(
            imageVector = Icons.Default.Star,
            contentDescription = "রেটিং",
            tint = StarGold,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = String.format("%.1f", rating),
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        )
        if (reviewsCount != null) {
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = "($reviewsCount)",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
fun WorkerAvatar(
    photoUri: String?,
    nameBn: String,
    avatarBgColorHex: Long = 0xFF0A6847,
    size: Dp = 50.dp,
    showOnlineIndicator: Boolean = false,
    isOnline: Boolean = true,
    modifier: Modifier = Modifier
) {
    val initials = nameBn.trim().split("\\s+".toRegex())
        .mapNotNull { it.firstOrNull()?.toString() }
        .take(2)
        .joinToString("")
        .ifBlank { nameBn.take(2) }

    Box(modifier = modifier.size(size)) {
        if (!photoUri.isNullOrBlank()) {
            AsyncImage(
                model = photoUri,
                contentDescription = nameBn,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .border(1.5.dp, MaterialTheme.colorScheme.primaryContainer, CircleShape)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color(avatarBgColorHex)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initials,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.38f).sp
                )
            }
        }

        if (showOnlineIndicator) {
            val dotSize = (size.value * 0.28f).coerceIn(10f, 16f).dp
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .clip(CircleShape)
                    .background(if (isOnline) SuccessGreen else Color.Gray)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                    .align(Alignment.BottomEnd)
            )
        }
    }
}
