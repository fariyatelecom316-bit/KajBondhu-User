package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WalletTransactionEntity
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.UrgentRed
import com.example.ui.viewmodel.UserMode

@Composable
fun WalletScreen(
    userMode: UserMode,
    transactions: List<WalletTransactionEntity>,
    onAddMoney: (Int, String) -> Unit,
    onWithdrawMoney: (Int, String) -> Unit,
    paymentMessage: String? = null,
    onClearPaymentMessage: () -> Unit = {},
    onVerifyPendingBkash: () -> Unit = {},
    onRefresh: () -> Unit = {},
    modifier: Modifier = Modifier,
    onBackClick: (() -> Unit)? = null
) {
    val totalBalance = transactions.sumOf { if (it.isCredit) it.amount else -it.amount }.coerceAtLeast(0)
    var amountText = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var selectedMethod = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("bKash") }

    Column(modifier.fillMaxSize()) {
        if (onBackClick != null) Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "পিছনে") }
            Text("ডিজিটাল ওয়ালেট", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "রিফ্রেশ") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Card(Modifier.fillMaxWidth().padding(16.dp), RoundedCornerShape(20.dp)) {
                    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF0A6847), Color(0xFF022C22)))).padding(20.dp)) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AccountBalanceWallet, null, tint = Color(0xFFFBBF24))
                                Spacer(Modifier.width(6.dp))
                                Text(if (userMode == UserMode.CLIENT) "গ্রাহক ডিজিটাল ওয়ালেট" else "কারিগর উপার্জন ওয়ালেট", color = Color.White)
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("মোট ব্যালেন্স", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
                            Text("৳ $totalBalance", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("ওয়ালেটে টাকা যোগ করুন", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = amountText.value, onValueChange = { amountText.value = it.filter(Char::isDigit) },
                            label = { Text("টাকার পরিমাণ") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("bKash", "Nagad", "Rocket").forEach { method ->
                                FilterChip(selected = selectedMethod.value == method, onClick = { selectedMethod.value = method }, label = { Text(method) })
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { amountText.value.toIntOrNull()?.let { onAddMoney(it, selectedMethod.value) } }, modifier = Modifier.fillMaxWidth()) {
                            Text("পেমেন্ট শুরু করুন")
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("পেমেন্ট সফল হলেই server-side verification-এর পর ব্যালেন্স যোগ হবে।", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (paymentMessage != null) item {
                Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(paymentMessage, Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp)
                        if (paymentMessage.contains("bKash", ignoreCase = true)) {
                            TextButton(onClick = onVerifyPendingBkash) { Text("যাচাই") }
                        }
                        TextButton(onClick = onClearPaymentMessage) { Text("ঠিক আছে") }
                    }
                }
            }
            item {
                Surface(Modifier.fillMaxWidth().padding(16.dp), RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.5f)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column { Text("নিরাপদ ওয়ালেট", fontWeight = FontWeight.Bold); Text("শুধু যাচাই হওয়া পেমেন্ট ledger-এ যোগ হবে।", fontSize = 11.sp) }
                    }
                }
            }
            item { Text("লেনদেনের ইতিহাস", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }
            items(transactions, key = { it.externalId ?: "local-${it.id}" }) { TransactionRowCard(it) }
            if (transactions.isEmpty()) item { Text("এখনও কোনো verified transaction নেই।", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
fun TransactionRowCard(transaction: WalletTransactionEntity, modifier: Modifier = Modifier) {
    Card(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(if (transaction.isCredit) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)), contentAlignment = Alignment.Center) {
                Icon(if (transaction.isCredit) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown, null, tint = if (transaction.isCredit) SuccessGreen else UrgentRed)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(transaction.titleBn, fontWeight = FontWeight.Bold); Text("${transaction.paymentMethod} • ${transaction.dateString}", fontSize = 11.sp, color = Color.Gray) }
            Text("${if (transaction.isCredit) "+" else "-"} ৳${transaction.amount}", fontWeight = FontWeight.Bold, color = if (transaction.isCredit) SuccessGreen else UrgentRed)
        }
    }
}
