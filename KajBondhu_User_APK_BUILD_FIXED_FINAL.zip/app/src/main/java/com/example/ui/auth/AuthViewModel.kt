package com.example.ui.auth

import android.app.Activity
import android.app.Application
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.GoogleAuthProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val isAuthenticated: Boolean = false,
    val isLoading: Boolean = false,
    val userPhoneNumber: String = "",
    val displayName: String = "",
    val email: String = "",
    val currentUserUid: String? = null,
    val errorMessage: String? = null,
    val infoMessage: String? = null,
    val isFirebaseConfigured: Boolean = false
)

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val auth: FirebaseAuth? by lazy {
        try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseAuth not available (google-services.json pending): ${e.message}")
            null
        }
    }

    init {
        checkInitialAuthState()
    }

    private fun checkInitialAuthState() {
        val currentAuth = auth
        if (currentAuth != null) {
            val currentUser = currentAuth.currentUser
            _uiState.value = _uiState.value.copy(
                isFirebaseConfigured = true,
                isAuthenticated = currentUser != null,
                currentUserUid = currentUser?.uid,
                userPhoneNumber = currentUser?.phoneNumber ?: "",
                displayName = currentUser?.displayName ?: "",
                email = currentUser?.email ?: ""
            )
        } else {
            _uiState.value = _uiState.value.copy(
                isFirebaseConfigured = false,
                isAuthenticated = false,
                infoMessage = "Firebase google-services.json অপেক্ষমাণ"
            )
        }
    }

    fun signInWithGoogle(activity: Activity) {
        val firebaseAuth = auth
        if (firebaseAuth == null) {
            _uiState.value = _uiState.value.copy(errorMessage = "Firebase কনফিগারেশন পাওয়া যায়নি।")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null, infoMessage = null)
            try {
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(activity.getString(com.example.R.string.default_web_client_id))
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = CredentialManager.create(activity).getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    val googleCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val firebaseCredential = GoogleAuthProvider.getCredential(googleCredential.idToken, null)
                    firebaseAuth.signInWithCredential(firebaseCredential)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val user = task.result?.user
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    isAuthenticated = true,
                                    currentUserUid = user?.uid,
                                    userPhoneNumber = user?.phoneNumber ?: "",
                                    displayName = user?.displayName ?: "",
                                    email = user?.email ?: "",
                                    errorMessage = null,
                                    infoMessage = "Google Account দিয়ে সফলভাবে লগইন হয়েছে।"
                                )
                            } else {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    errorMessage = task.exception?.localizedMessage ?: "Google লগইন ব্যর্থ হয়েছে।"
                                )
                            }
                        }
                } else {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = "Google credential পাওয়া যায়নি।")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Google sign-in failed: ${e.message}", e)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.localizedMessage ?: "Google লগইন বাতিল বা ব্যর্থ হয়েছে।"
                )
            }
        }
    }

    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "Error signing out: ${e.message}")
        }
        _uiState.value = AuthUiState(
            isAuthenticated = false,
            isFirebaseConfigured = auth != null
        )
    }


    companion object {
        private const val TAG = "AuthViewModel"
    }
}
