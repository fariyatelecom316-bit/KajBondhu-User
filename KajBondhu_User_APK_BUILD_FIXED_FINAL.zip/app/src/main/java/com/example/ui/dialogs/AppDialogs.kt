package com.example.ui.dialogs

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ChatMessageEntity
import com.example.data.model.JobRequestEntity
import com.example.data.model.ServiceCategory
import com.example.data.model.WorkerEntity
import com.example.ui.components.RatingBarDisplay
import com.example.ui.components.WorkerAvatar
import com.example.ui.components.dialPhoneNumber
import com.example.ui.theme.StarGold
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.UrgentRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostJobDialog(
    categories: List<ServiceCategory>,
    initialCategoryId: String?,
    currentLocation: String,
    onDismiss: () -> Unit,
    onSubmit: (
        title: String,
        categoryId: String,
        description: String,
        address: String,
        budget: Int,
        isUrgent: Boolean,
        scheduledDate: String,
        scheduledTime: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedCatId by remember {
        mutableStateOf(initialCategoryId ?: categories.firstOrNull()?.id ?: "electrician")
    }
    var description by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("$currentLocation, ঢাকা") }
    var budgetText by remember { mutableStateOf("500") }
    var isUrgent by remember { mutableStateOf(false) }
    var scheduledDate by remember { mutableStateOf("আজকে") }
    var scheduledTime by remember { mutableStateOf("জরুরি") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
                .testTag("post_job_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "নতুন কাজের বিজ্ঞপ্তি দিন",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            text = "দক্ষ ও ভেরিফায়েড কারিগর আপনার সাথে যোগাযোগ করবেন",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "বন্ধ")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Category Selector
                Text(
                    text = "কাজের বিভাগ নির্বাচন করুন *",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        val isSelected = cat.id == selectedCatId
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedCatId = cat.id }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(text = cat.iconEmoji, fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = cat.titleBn,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                    Text(
                                        text = cat.titleEn,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontSize = 9.sp,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title Input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("কাজের শিরোনাম (Title)") },
                    placeholder = { Text("যেমন: ফ্যানের রেগুলেটর মেরামত") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("job_title_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Description Input
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("সমস্যার বিস্তারিত বিবরণ") },
                    placeholder = { Text("সমস্যাটি বিস্তারিত লিখুন...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .testTag("job_desc_input"),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Address Input
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("ঠিকানা বা লোকেশন *") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("job_address_input"),
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Budget & Urgent Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = budgetText,
                        onValueChange = { budgetText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("বাজেট (৳)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("job_budget_input"),
                        singleLine = true
                    )

                    // Urgent Switch
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isUrgent) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { isUrgent = !isUrgent }
                            .padding(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "জরুরি সেবা?",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isUrgent) UrgentRed else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Text(
                                    text = "দ্রুত রেসপন্স",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 9.sp,
                                        color = Color.Gray
                                    )
                                )
                            }
                            Switch(
                                checked = isUrgent,
                                onCheckedChange = { isUrgent = it }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scheduled Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = scheduledDate,
                        onValueChange = { scheduledDate = it },
                        label = { Text("তারিখ (দিন)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = scheduledTime,
                        onValueChange = { scheduledTime = it },
                        label = { Text("সময় (বেলা)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Submit Button
                Button(
                    onClick = {
                        val budget = budgetText.toIntOrNull() ?: 500
                        val finalTitle = title.ifBlank {
                            val cat = categories.find { it.id == selectedCatId }
                            "${cat?.titleBn ?: "জরুরি"} সার্ভিস প্রয়োজন"
                        }
                        onSubmit(
                            finalTitle,
                            selectedCatId,
                            description.ifBlank { "জরুরি সার্ভিস" },
                            address,
                            budget,
                            isUrgent,
                            scheduledDate,
                            scheduledTime
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_post_job_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(
                        text = "বিজ্ঞপ্তি প্রকাশ করুন",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BookWorkerDirectDialog(
    worker: WorkerEntity,
    currentLocation: String,
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        description: String,
        address: String,
        budget: Int
    ) -> Unit
) {
    var taskTitle by remember { mutableStateOf("${worker.categoryTitleBn} সার্ভিস") }
    var taskDesc by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("$currentLocation, ঢাকা") }
    var budgetText by remember { mutableStateOf("${worker.hourlyRate}") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                WorkerAvatar(
                    photoUri = worker.photoUri,
                    nameBn = worker.nameBn,
                    avatarBgColorHex = worker.avatarBgColorHex,
                    size = 42.dp,
                    showOnlineIndicator = true,
                    isOnline = worker.isOnline
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "${worker.nameBn}-কে বুক করুন",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${worker.categoryTitleBn} • ৳${worker.hourlyRate}/ঘণ্টা",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary)
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = taskTitle,
                    onValueChange = { taskTitle = it },
                    label = { Text("কাজের নাম") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = taskDesc,
                    onValueChange = { taskDesc = it },
                    label = { Text("কাজের বিবরণ (ঐচ্ছিক)") },
                    placeholder = { Text("কী কাজ করাতে চান...") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("কাজের ঠিকানা") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("প্রস্তাবিত বাজেট (৳)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val budget = budgetText.toIntOrNull() ?: worker.hourlyRate
                    onConfirm(
                        taskTitle.ifBlank { "${worker.categoryTitleBn} সার্ভিস" },
                        taskDesc.ifBlank { "জরুরি সার্ভিস" },
                        address,
                        budget
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("বুকিং কনফার্ম", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
fun WorkerDetailDialog(
    worker: WorkerEntity,
    onDismiss: () -> Unit,
    onBookClick: () -> Unit,
    onEditClick: (() -> Unit)? = null,
    onWalletClick: (() -> Unit)? = null
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .testTag("worker_detail_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Top close & edit button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "কারিগর প্রোফাইল",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (onEditClick != null) {
                            IconButton(onClick = onEditClick) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "প্রোফাইল সম্পাদনা",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "বন্ধ")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Profile Header Card
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WorkerAvatar(
                        photoUri = worker.photoUri,
                        nameBn = worker.nameBn,
                        avatarBgColorHex = worker.avatarBgColorHex,
                        size = 64.dp,
                        showOnlineIndicator = true,
                        isOnline = worker.isOnline
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = worker.nameBn,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            if (worker.isVerified) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "যাচাইকৃত",
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Text(
                            text = worker.categoryTitleBn,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = worker.area,
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                            )
                        }
                        Text(
                            text = if (worker.isOnline) "🟢 সক্রিয় (Online)" else "⚪ অফলাইন",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (worker.isOnline) SuccessGreen else Color.Gray,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Profile actions: Edit & Wallet
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (onEditClick != null) {
                        OutlinedButton(
                            onClick = onEditClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("edit_profile_button_in_detail"),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("এডিট প্রোফাইল", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    if (onWalletClick != null) {
                        OutlinedButton(
                            onClick = {
                                onDismiss()
                                onWalletClick()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("worker_wallet_button_in_detail"),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("আয় ও ওয়ালেট", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Stats Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = StarGold, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(text = "${worker.rating}", fontWeight = FontWeight.Bold)
                        }
                        Text(text = "${worker.reviewsCount} রিভিউ", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "${worker.completedJobsCount}+", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(text = "কাজ সম্পন্ন", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "${worker.experienceYears} বছর", fontWeight = FontWeight.Bold)
                        Text(text = "অভিজ্ঞতা", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "৳${worker.hourlyRate}", fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                        Text(text = "ঘণ্টা প্রতি", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bio
                Text(
                    text = "পরিচিতি",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = worker.bioBn,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Skills Badges
                Text(
                    text = "বিশেষ দক্ষতা",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    worker.skillsBn.split(",").map { it.trim() }.forEach { skill ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                        ) {
                            Text(
                                text = "✓ $skill",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons (Call & Book)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { dialPhoneNumber(context, worker.phone) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = "ফোন")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("কল করুন")
                    }
                    Button(
                        onClick = {
                            onDismiss()
                            onBookClick()
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("সরাসরি বুকিং", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatDialog(
    job: JobRequestEntity,
    messages: List<ChatMessageEntity>,
    onDismiss: () -> Unit,
    onSendMessage: (String) -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    var inputText by remember { mutableStateOf("") }
    val quickReplies = listOf(
        "আমি ২০ মিনিটের মধ্যে পৌঁছাবো।",
        "ঠিকানা আরেকটু স্পষ্ট করে বলবেন কি?",
        "কাজটি শুরু করতে পেরেছি।",
        "ধন্যবাদ, কাজ সফলভাবে সম্পন্ন হয়েছে!"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f)
                .testTag("chat_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Top Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "মেসেজ ও চ্যাট",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${job.assignedWorkerName ?: job.clientName} • ${job.title}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary),
                            maxLines = 1
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "বন্ধ")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Chat Messages List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "কথোপকথন শুরু করতে মেসেজ লিখুন...",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                                )
                            }
                        }
                    } else {
                        items(messages) { msg ->
                            val isMe = msg.isClient
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(
                                        topStart = 14.dp,
                                        topEnd = 14.dp,
                                        bottomStart = if (isMe) 14.dp else 2.dp,
                                        bottomEnd = if (isMe) 2.dp else 14.dp
                                    ),
                                    color = if (isMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.widthIn(max = 280.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = msg.senderName,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.primary
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = msg.messageText,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Quick reply chips
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(quickReplies) { reply ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onSendMessage(reply) }
                        ) {
                            Text(
                                text = reply,
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("মেসেজ লিখুন...") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (inputText.isNotBlank()) {
                                    val textToSend = inputText.trim()
                                    inputText = ""
                                    keyboardController?.hide()
                                    onSendMessage(textToSend)
                                }
                            }
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                val textToSend = inputText.trim()
                                inputText = ""
                                keyboardController?.hide()
                                onSendMessage(textToSend)
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .testTag("chat_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "পাঠান",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReviewJobDialog(
    job: JobRequestEntity,
    onDismiss: () -> Unit,
    onSubmit: (rating: Int, reviewText: String) -> Unit
) {
    var rating by remember { mutableStateOf(5) }
    var reviewText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "কাজের মূল্যায়ন ও রিভিউ",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${job.assignedWorkerName ?: "কারিগর"}-এর কাজ কেমন ছিল?",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                Spacer(modifier = Modifier.height(14.dp))

                // Clickable Star Rating Bar
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..5) {
                        IconButton(onClick = { rating = i }) {
                            Icon(
                                imageVector = if (i <= rating) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "$i স্টার",
                                tint = StarGold,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                Text(
                    text = when (rating) {
                        5 -> "অসাধারণ! (Excellent)"
                        4 -> "খুব ভালো (Very Good)"
                        3 -> "মোটামুটি (Average)"
                        2 -> "খারাপ (Poor)"
                        else -> "খুবই অসন্তোষজনক"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = reviewText,
                    onValueChange = { reviewText = it },
                    label = { Text("রিভিউ মন্তব্য") },
                    placeholder = { Text("কাজের মান সম্পর্কে কিছু লিখুন...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        rating,
                        reviewText.ifBlank { "চমৎকার ও দক্ষ সেবা!" }
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("রিভিউ জমা দিন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
fun LocationPickerDialog(
    currentLocation: String,
    onDismiss: () -> Unit,
    onSelectLocation: (String) -> Unit
) {
    val locations = listOf(
        "ধানমন্ডি, ঢাকা",
        "মিরপুর, ঢাকা",
        "গুলশান, ঢাকা",
        "বনানী, ঢাকা",
        "উত্তরা, ঢাকা",
        "মোহাম্মদপুর, ঢাকা",
        "বাড্ডা, ঢাকা",
        "বসুন্ধরা, ঢাকা",
        "মালিবাগ, ঢাকা",
        "যাত্রাবাড়ী, ঢাকা",
        "আগ্রাবাদ, চট্টগ্রাম",
        "জিইসি, চট্টগ্রাম"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("এলাকা নির্বাচন করুন", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().height(280.dp)) {
                items(locations) { loc ->
                    val isSelected = loc == currentLocation
                    Surface(
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onSelectLocation(loc) }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = loc,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("বন্ধ করুন")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditWorkerProfileDialog(
    worker: WorkerEntity,
    categories: List<ServiceCategory>,
    onDismiss: () -> Unit,
    onSave: (WorkerEntity) -> Unit
) {
    var nameBn by remember { mutableStateOf(worker.nameBn) }
    var nameEn by remember { mutableStateOf(worker.nameEn) }
    var phone by remember { mutableStateOf(worker.phone) }
    var area by remember { mutableStateOf(worker.area) }
    var selectedCategoryId by remember { mutableStateOf(worker.categoryId) }
    var hourlyRateStr by remember { mutableStateOf(worker.hourlyRate.toString()) }
    var experienceYearsStr by remember { mutableStateOf(worker.experienceYears.toString()) }
    var skillsBn by remember { mutableStateOf(worker.skillsBn) }
    var bioBn by remember { mutableStateOf(worker.bioBn) }
    var isOnline by remember { mutableStateOf(worker.isOnline) }
    var photoUri by remember { mutableStateOf(worker.photoUri) }
    var avatarBgColorHex by remember { mutableStateOf(worker.avatarBgColorHex) }

    val isNewWorker = worker.id == 0L
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                photoUri = uri.toString()
            }
        }
    )

    val colorPresets = listOf(
        0xFF0A6847L, // Emerald green
        0xFF1E40AFL, // Navy blue
        0xFF7C2D12L, // Terracotta / warm red-brown
        0xFF4C1D95L, // Deep purple
        0xFF0F766EL, // Teal
        0xFFB45309L, // Amber brown
        0xFF374151L  // Dark slate
    )

    val isFormValid = nameBn.isNotBlank() && phone.isNotBlank() && area.isNotBlank()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.92f)
                .testTag("edit_worker_profile_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isNewWorker) "নতুন কারিগর নিবন্ধন" else "কারিগর প্রোফাইল সম্পাদনা",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "আপনার কাজের তথ্য ও যোগাযোগের নম্বর সঠিক দিন",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "বন্ধ")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Body
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Photo Upload & Preview Section
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "প্রোফাইল ছবি (Profile Photo)",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            WorkerAvatar(
                                photoUri = photoUri,
                                nameBn = nameBn.ifBlank { "কারিগর" },
                                avatarBgColorHex = avatarBgColorHex,
                                size = 84.dp,
                                showOnlineIndicator = true,
                                isOnline = isOnline
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("pick_photo_button")
                                ) {
                                    Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (photoUri != null) "ছবি পরিবর্তন" else "ছবি যোগ করুন",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                if (photoUri != null) {
                                    OutlinedButton(
                                        onClick = { photoUri = null },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = UrgentRed),
                                        modifier = Modifier.testTag("remove_photo_button")
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("ছবি সরান", fontSize = 12.sp)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "অথবা অ্যাভাটার ব্যাকগ্রাউন্ড কালার নির্বাচন করুন:",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                colorPresets.forEach { colorHex ->
                                    val isSelected = avatarBgColorHex == colorHex
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(colorHex))
                                            .border(
                                                width = if (isSelected) 3.dp else 1.dp,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White,
                                                shape = CircleShape
                                            )
                                            .clickable { avatarBgColorHex = colorHex }
                                    )
                                }
                            }
                        }
                    }

                    // Worker Name Bengali
                    OutlinedTextField(
                        value = nameBn,
                        onValueChange = { nameBn = it },
                        label = { Text("নাম (বাংলায়) *") },
                        placeholder = { Text("যেমন: মোঃ রফিকুল ইসলাম") },
                        isError = nameBn.isBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("worker_name_bn_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    // Worker Name English
                    OutlinedTextField(
                        value = nameEn,
                        onValueChange = { nameEn = it },
                        label = { Text("নাম (ইংরেজিতে)") },
                        placeholder = { Text("e.g. Md. Rafiqul Islam") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("worker_name_en_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    // Service Category Selection
                    Column {
                        Text(
                            text = "কাজের বিভাগ *",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(categories) { cat ->
                                val isSelected = cat.id == selectedCategoryId
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                                    modifier = Modifier
                                        .clickable { selectedCategoryId = cat.id }
                                        .testTag("category_chip_${cat.id}")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "${cat.iconEmoji} ${cat.titleBn}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Phone Number
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("মোবাইল নম্বর *") },
                        placeholder = { Text("যেমন: 01712345678") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("worker_phone_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    // Service Area
                    OutlinedTextField(
                        value = area,
                        onValueChange = { area = it },
                        label = { Text("কাজের এলাকা *") },
                        placeholder = { Text("যেমন: মিরপুর, ঢাকা") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("worker_area_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    // Experience & Hourly Rate Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = experienceYearsStr,
                            onValueChange = { experienceYearsStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("অভিজ্ঞতা (বছর)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("worker_experience_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = hourlyRateStr,
                            onValueChange = { hourlyRateStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("মজুরি (৳/ঘণ্টা)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("worker_rate_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }

                    // Skills (comma separated)
                    OutlinedTextField(
                        value = skillsBn,
                        onValueChange = { skillsBn = it },
                        label = { Text("বিশেষ দক্ষতা (কমা দিয়ে)") },
                        placeholder = { Text("যেমন: ফ্যান ফিটিং, ওয়্যারিং...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("worker_skills_input"),
                        shape = RoundedCornerShape(12.dp),
                        minLines = 2
                    )

                    // Bio
                    OutlinedTextField(
                        value = bioBn,
                        onValueChange = { bioBn = it },
                        label = { Text("নিজের সম্পর্কে বিবরণ") },
                        placeholder = { Text("আপনার কাজের অভিজ্ঞতা ও নির্ভরযোগ্যতা লিখুন...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("worker_bio_input"),
                        shape = RoundedCornerShape(12.dp),
                        minLines = 2
                    )

                    // Online Availability Toggle
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isOnline) "🟢 কাজে প্রস্তুত (Online)" else "⚪ বর্তমানে ব্যস্ত (Offline)",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isOnline) SuccessGreen else Color.Gray
                                    )
                                )
                            }
                            Switch(
                                checked = isOnline,
                                onCheckedChange = { isOnline = it },
                                modifier = Modifier.testTag("worker_online_switch")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("বাতিল")
                    }
                    Button(
                        onClick = {
                            if (isFormValid) {
                                val selectedCategory = categories.find { it.id == selectedCategoryId }
                                    ?: categories.firstOrNull()
                                val categoryTitle = selectedCategory?.titleBn ?: "সাধারণ কাজ"
                                val updatedWorker = worker.copy(
                                    nameBn = nameBn.trim(),
                                    nameEn = nameEn.trim().ifBlank { nameBn.trim() },
                                    phone = phone.trim(),
                                    area = area.trim(),
                                    categoryId = selectedCategoryId,
                                    categoryTitleBn = categoryTitle,
                                    hourlyRate = hourlyRateStr.toIntOrNull() ?: worker.hourlyRate,
                                    experienceYears = experienceYearsStr.toIntOrNull() ?: worker.experienceYears,
                                    skillsBn = skillsBn.trim(),
                                    bioBn = bioBn.trim(),
                                    isOnline = isOnline,
                                    photoUri = photoUri,
                                    avatarBgColorHex = avatarBgColorHex
                                )
                                onSave(updatedWorker)
                            }
                        },
                        enabled = isFormValid,
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag("save_worker_profile_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = if (isNewWorker) "নিবন্ধন সম্পন্ন করুন" else "সংরক্ষণ করুন",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ClientProfileDialog(
    userLocation: String,
    completedJobsCount: Int,
    onDismiss: () -> Unit,
    onWalletClick: () -> Unit,
    onPostJobClick: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .testTag("client_profile_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "গ্রাহক প্রোফাইল",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "বন্ধ")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Avatar and info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "সম্মানিত গ্রাহক",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = userLocation,
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Menu items
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable {
                            onDismiss()
                            onWalletClick()
                        }
                        .testTag("client_profile_wallet_item"),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "ওয়ালেট",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "আমার ওয়ালেট (My Wallet)",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onDismiss()
                            onPostJobClick()
                        }
                        .testTag("client_profile_post_job_item"),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2563EB)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FlashOn,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "নতুন কাজের বিজ্ঞপ্তি দিন",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("বন্ধ করুন")
                }
            }
        }
    }
}
