package com.example.data.ai

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val isUser: Boolean,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val userRole: String = "CLIENT" // "CLIENT" or "WORKER"
)

class GeminiAiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    // Recommended model per skill: gemini-2.5-flash for basic text & Q&A
    private val modelName = "gemini-2.5-flash"
    private val baseUrl = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent"

    private fun getSystemPrompt(userRole: String): String {
        return if (userRole == "WORKER") {
            """
            তুমি "কাজবন্ধু" (KajBondhu) প্ল্যাটফর্মের কৃত্রিম বুদ্ধিমত্তা সম্পন্ন এআই সহকারী (AI Assistant)।
            ব্যবহারকারী একজন "কারিগর/মিস্ত্রি" (Worker/Technician)।
            তোমার দায়িত্ব:
            ১. কারিগরি কাজের সমস্যা সমাধান, পার্টস শনাক্তকরণ এবং নিখুঁত মেরামতের পরামর্শ দেওয়া।
            ২. কাজের সময় বিদ্যুৎ ও শারীরিক নিরাপত্তা (Safety first) নিশ্চিত করার গাইডলাইন দেওয়া।
            ৩. কাজের ন্যায্য মজুরি নির্ধারণ ও গ্রাহকের সাথে পেশাদার যোগাযোগের টিপস দেওয়া।
            ৪. উত্তর সংক্ষিপ্ত, ব্যবহারিক ও সহজে বোঝার মতো বাংলায় উপস্থাপন করা।
            """.trimIndent()
        } else {
            """
            তুমি "কাজবন্ধু" (KajBondhu) প্ল্যাটফর্মের স্মার্ট সেবা সহায়ক (AI Assistant)।
            ব্যবহারকারী একজন "সেবা গ্রহণকারী গ্রাহক" (Client/Customer)।
            তোমার দায়িত্ব:
            ১. বাসাবাড়ি বা অফিসের যেকোনো সমস্যা (ইলেকট্রিক, প্লাম্বিং, এসি, ক্লিনিং, কাঠমিস্ত্রি ইত্যাদি) শুনে সঠিক সেবা বিভাগ ও সম্ভাব্য কারণ চিহ্নিত করা।
            ২. সমস্যার আনুমানিক জরুরি সমাধান এবং প্রাথমিক সুরক্ষা টিপস দেওয়া।
            ৩. আনুমানিক বাজেট বা মিস্ত্রি খরচ সম্পর্কে ধারণা প্রদান করা।
            ৪. উত্তর খুব বিনম্র, স্পষ্ট এবং নির্ভরযোগ্য খাঁটি বাংলায় উপস্থাপন করা।
            """.trimIndent()
        }
    }

    suspend fun sendMessage(
        history: List<AiChatMessage>,
        userMessage: String,
        userRole: String = "CLIENT"
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            field.get(null) as? String ?: ""
        } catch (e: Throwable) {
            ""
        }

        // If no real API key is configured yet in secrets, provide a smart fallback response
        val isRealKey = !apiKey.isNullOrBlank() &&
                apiKey != "MY_GEMINI_API_KEY" &&
                apiKey != "YOUR_GEMINI_API_KEY"

        if (!isRealKey) {
            Log.w("GeminiAiService", "No valid API key found. Providing smart local assistant response for role: $userRole.")
            return@withContext getLocalSmartResponse(userMessage, userRole = userRole)
        }

        try {
            val url = "$baseUrl?key=$apiKey"

            // Construct contents array with previous turns (up to 8 turns to stay focused)
            val contentsArray = JSONArray()
            val relevantHistory = history.takeLast(8)
            for (msg in relevantHistory) {
                val turnObj = JSONObject()
                turnObj.put("role", if (msg.isUser) "user" else "model")
                val partsArray = JSONArray()
                val partObj = JSONObject()
                partObj.put("text", msg.message)
                partsArray.put(partObj)
                turnObj.put("parts", partsArray)
                contentsArray.put(turnObj)
            }

            // Add current user message
            val currentTurn = JSONObject()
            currentTurn.put("role", "user")
            val currentParts = JSONArray()
            val currentPartObj = JSONObject()
            currentPartObj.put("text", userMessage)
            currentParts.put(currentPartObj)
            currentTurn.put("parts", currentParts)
            contentsArray.put(currentTurn)

            // System Instruction
            val systemInstructionObj = JSONObject()
            val sysPartsArray = JSONArray()
            val sysPartObj = JSONObject()
            sysPartObj.put("text", getSystemPrompt(userRole))
            sysPartsArray.put(sysPartObj)
            systemInstructionObj.put("parts", sysPartsArray)

            // Request body JSON
            val requestJson = JSONObject()
            requestJson.put("contents", contentsArray)
            requestJson.put("systemInstruction", systemInstructionObj)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBodyString = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e("GeminiAiService", "API error: ${response.code} - $responseBodyString")
                return@withContext getLocalSmartResponse(userMessage, userRole = userRole, isErrorFallback = true)
            }

            val jsonResponse = JSONObject(responseBodyString)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val text = parts.getJSONObject(0).optString("text", "")
                    if (text.isNotBlank()) {
                        return@withContext text.trim()
                    }
                }
            }

            return@withContext getLocalSmartResponse(userMessage, userRole = userRole)
        } catch (e: Exception) {
            Log.e("GeminiAiService", "Network/Gemini error: ${e.message}", e)
            return@withContext getLocalSmartResponse(userMessage, userRole = userRole, isErrorFallback = true)
        }
    }

    private fun getLocalSmartResponse(query: String, userRole: String = "CLIENT", isErrorFallback: Boolean = false): String {
        val q = query.lowercase()
        val baseReply = if (userRole == "WORKER") {
            // Worker-centric responses (Technical tips, safety, quotes, rating, customer handling)
            when {
                q.contains("দাম") || q.contains("রেট") || q.contains("মজুরি") || q.contains("টাকা") || q.contains("কাস্টমার") || q.contains("fee") -> {
                    """
                    👷‍♂️ কারিগর ভাই, কাজবন্ধু প্ল্যাটফর্মে ন্যায্য মজুরি নিশ্চিত করার পরামর্শ:
                    ১. কাজের ধরণ ও আনুমানিক সময় আগে বুঝে নিয়ে গ্রাহককে প্রাথমিক এস্টিমেট দিন।
                    ২. সাধারণ কাজের বেসিক ভিজিট ফি ৩৫০-৪৫০ টাকার মধ্যে রাখুন।
                    ৩. কোনো স্পেয়ার পার্টস কিনতে হলে আসল ভাউচার গ্রাহককে দেখিয়ে স্বচ্ছতা বজায় রাখুন। এতে গ্রাহকের আস্থা ও রেটিং বাড়ে!
                    """.trimIndent()
                }
                q.contains("সেফটি") || q.contains("নিরাপত্তা") || q.contains("শক") || q.contains("কারেন্ট") || q.contains("দুর্ঘটনা") -> {
                    """
                    ⚠️ নিরাপত্তা সতর্কতা (Safety First):
                    ১. যেকোনো ইলেকট্রিক কাজে হাত দেওয়ার আগে মেইন সার্কিট ব্রেকার (MCB) বা ডিবি বোর্ড বন্ধ করুন।
                    ২. সর্বদা টেস্টার দিয়ে ফেজ চেক করে রাবারের জুতো পরিধান করে কাজ করুন।
                    ৩. মই বা উঁচু স্থানে কাজের সময় হেলমেট ও নিরাপত্তা বেল্ট ব্যবহার বাধ্যতামূলক।
                    """.trimIndent()
                }
                q.contains("এসি") || q.contains("গ্যাস") || q.contains("কুলিং") || q.contains("প্রেশার") -> {
                    """
                    ❄️ এসি সার্ভিসিং টেকনিক্যাল গাইড:
                    ১. সাকশন প্রেশার চেক করুন: R22 গ্যাসের ক্ষেত্রে ৬৫-৭০ psi এবং R410A ও R32 গ্যাসের ক্ষেত্রে ১২০-১৪০ psi সাধারণত স্ট্যান্ডার্ড।
                    ২. গ্যাস চার্জ করার পূর্বে সম্পূর্ণ লাইনে নাইট্রোজেন বা ভ্যাকুয়াম পাম্প দিয়ে লিকেজ টেস্ট নিশ্চিত করুন।
                    """.trimIndent()
                }
                q.contains("ফ্যান") || q.contains("মোটর") || q.contains("ক্যাপাসিটর") || q.contains("জ্যাম") -> {
                    """
                    ⚡ ফ্যান ও মোটর ট্রাবলশুটিং:
                    ১. ফ্যান আস্তে ঘুরলে সাধারণত ২.৫ বা ৩.১৫ uF ক্যাপাসিটর দুর্বল হয়ে যায়।
                    ২. জাম থাকলে বুশ ও বিয়ারিংয়ে ভালো গ্রেডের লুব্রিকেটিং অয়েল বা গ্রিজ ব্যবহার করুন।
                    """.trimIndent()
                }
                else -> {
                    """
                    👷‍♂️ আসসালামু আলাইকুম কারিগর বন্ধু!
                    আমি আপনার সহকারী এআই। যেকোনো কাজের টেকনিক্যাল ট্রাবলশুটিং, স্পেয়ার পার্টস সিলেকশন, কাজের সময় নিরাপত্তা গাইড এবং ন্যায্য পারিশ্রমিক হিসাব করতে আমাকে নির্দ্বিধায় প্রশ্ন করতে পারেন।
                    """.trimIndent()
                }
            }
        } else {
            // Client-centric responses
            when {
                q.contains("ফ্যান") || q.contains("লাইট") || q.contains("fan") -> {
                    """
                    💡 ইলেকট্রিক্যাল সেবা পরামর্শ:
                    ফ্যানের গতি কমে যাওয়া সাধারণত ক্যাপাসিটর দুর্বল হওয়ার লক্ষণ। নতুন ক্যাপাসিটর লাগানো বা রেগুলেটর মেরামতে সাধারণত ৩৫০-৪৫০ টাকার মতো চার্জ হতে পারে।
                    """.trimIndent()
                }
                q.contains("এসি") || q.contains("ফ্রিজ") || q.contains("ac") -> {
                    """
                    ❄️ এসি ও ফ্রিজ সেবা পরামর্শ:
                    এসি ঠান্ডা কম হলে ফিল্টার ময়লা বা গ্যাস কমে যাওয়ার সম্ভাবনা থাকে। কাজবন্ধুর ভেরিফায়েড এসি টেকনিশিয়ান ডেকে মাস্টার ওয়াশ করিয়ে নিতে পারেন (আনুমানিক ৮০০-১২০০ টাকা)।
                    """.trimIndent()
                }
                q.contains("পাইপ") || q.contains("পানি") || q.contains("লিক") || q.contains("ট্যাপ") -> {
                    """
                    🔧 প্লাম্বিং সেবা পরামর্শ:
                    পাইপ লিক হলে দ্রুত মেইন পানির চাবি বন্ধ করে দিন। কাজবন্ধুর প্লাম্বাররা দ্রুত এসে টেফলন টেপ ও পিভিসি সলিউশন দিয়ে লিকেজ বন্ধ করে দিতে পারেন।
                    """.trimIndent()
                }
                else -> {
                    """
                    👋 আসসালামু আলাইকুম! কাজবন্ধু এআই এসিস্ট্যান্টে আপনাকে স্বাগতম।
                    আপনার বাসা বা অফিসের ইলেকট্রিক, প্লাম্বিং, এসি, ক্লিনিং বা যেকোনো সমস্যা সম্পর্কে আমাকে বলুন, আমি দ্রুত সঠিক সমাধান ও আনুমানিক খরচের ধারণা দিচ্ছি।
                    """.trimIndent()
                }
            }
        }

        return if (isErrorFallback) {
            "$baseReply\n\n*(অফলাইন স্মার্ট অ্যাসিস্ট্যান্ট মোড)*"
        } else {
            baseReply
        }
    }
}
