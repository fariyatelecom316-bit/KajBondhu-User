package com.example.data.repository

import com.example.data.local.ChatDao
import com.example.data.local.JobDao
import com.example.data.local.KajBondhuDatabase
import com.example.data.local.SeedData
import com.example.data.local.WalletDao
import com.example.data.local.WorkerDao
import com.example.data.model.ChatMessageEntity
import com.example.data.model.JobRequestEntity
import com.example.data.model.ServiceCategory
import com.example.data.model.WalletTransactionEntity
import com.example.data.model.WorkerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class KajBondhuRepository(private val database: KajBondhuDatabase) {
    private val workerDao: WorkerDao = database.workerDao()
    private val jobDao: JobDao = database.jobDao()
    private val chatDao: ChatDao = database.chatDao()
    private val walletDao: WalletDao = database.walletDao()

    /** No demo/sample records are inserted. Real data comes from authenticated users. */
    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        // Intentionally empty.
    }

    fun getCategories(): List<ServiceCategory> = SeedData.categories

    fun getAllWorkers(): Flow<List<WorkerEntity>> = workerDao.getAllWorkers()

    fun getWorkersByCategory(categoryId: String): Flow<List<WorkerEntity>> =
        workerDao.getWorkersByCategory(categoryId)

    fun getWorkerById(workerId: Long): Flow<WorkerEntity?> =
        workerDao.getWorkerById(workerId)

    fun searchWorkers(query: String): Flow<List<WorkerEntity>> =
        workerDao.searchWorkers(query)

    suspend fun insertWorker(worker: WorkerEntity): Long = withContext(Dispatchers.IO) {
        workerDao.insertWorker(worker)
    }

    suspend fun updateWorker(worker: WorkerEntity) = withContext(Dispatchers.IO) {
        workerDao.updateWorker(worker)
    }

    fun getAllJobs(): Flow<List<JobRequestEntity>> = jobDao.getAllJobs()

    fun getJobsByStatus(status: String): Flow<List<JobRequestEntity>> =
        jobDao.getJobsByStatus(status)

    fun getJobById(jobId: Long): Flow<JobRequestEntity?> = jobDao.getJobById(jobId)

    suspend fun postJob(job: JobRequestEntity): Long = withContext(Dispatchers.IO) {
        jobDao.insertJob(job)
    }

    suspend fun updateJobStatus(jobId: Long, newStatus: String) = withContext(Dispatchers.IO) {
        jobDao.updateStatus(jobId, newStatus)
    }

    suspend fun assignWorkerToJob(
        jobId: Long,
        workerId: Long,
        workerName: String,
        workerPhone: String,
        workerUid: String
    ) = withContext(Dispatchers.IO) {
        jobDao.assignWorker(jobId, "ACCEPTED", workerId, workerName, workerPhone, workerUid)
    }

    suspend fun submitReview(jobId: Long, rating: Int, review: String) = withContext(Dispatchers.IO) {
        jobDao.submitReview(jobId, rating, review)
    }

    suspend fun deleteJob(jobId: Long) = withContext(Dispatchers.IO) {
        jobDao.deleteJob(jobId)
    }

    fun getChatMessages(jobId: Long): Flow<List<ChatMessageEntity>> =
        chatDao.getMessagesForJob(jobId)

    suspend fun sendChatMessage(
        jobId: Long, senderName: String, isClient: Boolean, text: String,
        senderUid: String? = null, timestamp: Long = System.currentTimeMillis()
    ): Long = withContext(Dispatchers.IO) {
        chatDao.insertMessage(
            ChatMessageEntity(
                jobId = jobId, senderName = senderName, isClient = isClient,
                senderUid = senderUid, messageText = text, timestamp = timestamp
            )
        )
    }

    suspend fun insertChatMessages(messages: List<ChatMessageEntity>) = withContext(Dispatchers.IO) {
        if (messages.isNotEmpty()) chatDao.insertMessages(messages)
    }

    fun getWalletTransactions(ownerUid: String): Flow<List<WalletTransactionEntity>> =
        walletDao.getTransactionsForOwner(ownerUid)

    suspend fun insertWalletTransactions(transactions: List<WalletTransactionEntity>) = withContext(Dispatchers.IO) {
        if (transactions.isNotEmpty()) walletDao.insertTransactions(transactions)
    }

    suspend fun addWalletTransaction(titleBn: String, amount: Int, isCredit: Boolean, method: String, ownerUid: String) =
        withContext(Dispatchers.IO) {
            walletDao.insertTransaction(
                WalletTransactionEntity(
                    titleBn = titleBn,
                    amount = amount,
                    isCredit = isCredit,
                    paymentMethod = method,
                    dateString = "আজকের লেনদেন",
                    ownerUid = ownerUid
                )
            )
        }
}
