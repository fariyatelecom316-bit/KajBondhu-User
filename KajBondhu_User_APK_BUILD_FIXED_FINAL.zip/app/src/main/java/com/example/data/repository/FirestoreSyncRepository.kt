package com.example.data.repository

import android.util.Log
import com.example.data.model.ChatMessageEntity
import com.example.data.model.JobRequestEntity
import com.example.data.model.WorkerEntity
import com.example.data.model.WalletTransactionEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

/**
 * Cloud Firestore Synchronization Repository.
 * Gracefully handles Firebase initialization whether google-services.json is present or not.
 * Maps data models: Users, Worker Profiles, Job-Givers, Job Posts, Budgets, and Districts.
 */
class FirestoreSyncRepository {

    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not yet initialized (waiting for google-services.json): ${e.message}")
            null
        }
    }

    fun isFirestoreAvailable(): Boolean = firestore != null

    fun listenWalletLedger(ownerUid: String, onResult: (List<WalletTransactionEntity>) -> Unit): com.google.firebase.firestore.ListenerRegistration? {
        val db = firestore ?: return null
        if (ownerUid.isBlank()) return null
        return db.collection("wallet_ledger")
            .whereEqualTo("ownerUid", ownerUid)
            .addSnapshotListener { snap, error ->
                if (error != null || snap == null) {
                    onResult(emptyList())
                    return@addSnapshotListener
                }
                val items = snap.documents.mapNotNull { doc ->
                    val amount = doc.getDouble("amount")?.toInt() ?: return@mapNotNull null
                    val method = doc.getString("method") ?: "Payment"
                    val trx = doc.getString("trxID")?.takeIf { it.isNotBlank() }
                    val created = doc.getTimestamp("createdAt")?.toDate()?.time ?: doc.getLong("createdAt") ?: System.currentTimeMillis()
                    WalletTransactionEntity(
                        id = doc.id.hashCode().toLong(),
                        titleBn = "ওয়ালেটে টাকা যোগ",
                        amount = amount,
                        isCredit = true,
                        paymentMethod = if (trx != null) "$method • $trx" else method,
                        dateString = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(created)),
                        ownerUid = ownerUid,
                        timestamp = created,
                        externalId = doc.id
                    )
                }.sortedByDescending { it.timestamp }
                onResult(items)
            }
    }

    /**
     * Sync user profile to Firestore (both worker or client/job-giver).
     */
    fun syncUserProfile(
        userId: String,
        phone: String,
        name: String,
        role: String,
        email: String = "", // "CLIENT" or "WORKER"
        district: String = "ঢাকা",
        area: String = "মিরপুর"
    ) {
        val db = firestore ?: run {
            Log.d(TAG, "Firestore unavailable, user profile saved locally.")
            return
        }

        val userData = hashMapOf(
            "userId" to userId,
            "phone" to phone,
            "name" to name,
            "email" to email,
            "role" to role,
            "district" to district,
            "area" to area,
            "updatedAt" to System.currentTimeMillis()
        )

        db.collection(COLLECTION_USERS)
            .document(userId)
            .set(userData, SetOptions.merge())
            .addOnSuccessListener {
                Log.d(TAG, "User profile successfully synced to Firestore for user: $userId")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error syncing user profile to Firestore: ${e.message}")
            }
    }

    /**
     * Sync Worker Profile to Cloud Firestore under "workers" collection.
     */
    fun syncWorkerToFirestore(worker: WorkerEntity) {
        val db = firestore ?: return
        // A worker profile MUST have an authenticated Firebase UID.
        // Never create/update a cloud profile without an owner.
        val ownerUid = worker.ownerUid?.trim().orEmpty()
        if (ownerUid.isBlank()) {
            Log.w(TAG, "Blocked worker sync: missing ownerUid")
            return
        }
        val workerData = hashMapOf(
            "id" to worker.id,
            "nameBn" to worker.nameBn,
            "nameEn" to worker.nameEn,
            "categoryId" to worker.categoryId,
            "categoryTitleBn" to worker.categoryTitleBn,
            "phone" to worker.phone,
            "area" to worker.area,
            "district" to worker.district,
            "experienceYears" to worker.experienceYears,
            "hourlyRate" to worker.hourlyRate,
            "rating" to worker.rating,
            "reviewsCount" to worker.reviewsCount,
            "completedJobsCount" to worker.completedJobsCount,
            "bioBn" to worker.bioBn,
            "skillsBn" to worker.skillsBn,
            "isVerified" to worker.isVerified,
            "isOnline" to worker.isOnline,
            "avatarBgColorHex" to worker.avatarBgColorHex,
            "photoUri" to (worker.photoUri ?: ""),
            "ownerUid" to ownerUid,
            "updatedAt" to System.currentTimeMillis()
        )

        // One cloud document per Firebase user prevents one user's profile from
        // being addressed through another user's numeric/local worker id.
        val docId = ownerUid
        db.collection(COLLECTION_WORKERS)
            .document(docId)
            .set(workerData, SetOptions.merge())
            .addOnSuccessListener {
                Log.d(TAG, "Worker ${worker.nameBn} synced to Firestore doc: $docId")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Worker sync failed: ${e.message}")
            }
    }

    /**
     * Sync Job Post & Budget to Cloud Firestore under "job_posts" collection.
     */
    fun syncJobToFirestore(job: JobRequestEntity) {
        val db = firestore ?: return
        val ownerUid = job.ownerUid?.trim().orEmpty()
        if (ownerUid.isBlank()) {
            Log.w(TAG, "Blocked job sync: missing ownerUid")
            return
        }
        val jobData = hashMapOf(
            "id" to job.id,
            "title" to job.title,
            "categoryId" to job.categoryId,
            "categoryTitleBn" to job.categoryTitleBn,
            "description" to job.description,
            "clientName" to job.clientName,
            "clientPhone" to job.clientPhone,
            "address" to job.address,
            "area" to job.area,
            "budget" to job.budget,
            "isUrgent" to job.isUrgent,
            "scheduledDate" to job.scheduledDate,
            "scheduledTime" to job.scheduledTime,
            "status" to job.status,
            "assignedWorkerId" to (job.assignedWorkerId ?: -1L),
            "assignedWorkerName" to (job.assignedWorkerName ?: ""),
            "assignedWorkerPhone" to (job.assignedWorkerPhone ?: ""),
            "assignedWorkerUid" to (job.assignedWorkerUid ?: ""),
            "ratingGiven" to job.ratingGiven,
            "reviewGiven" to job.reviewGiven,
            "ownerUid" to ownerUid,
            "createdAtTimestamp" to job.createdAtTimestamp
        )

        val docId = if (job.id > 0) job.id.toString() else "job_${System.currentTimeMillis()}"
        db.collection(COLLECTION_JOBS)
            .document(docId)
            .set(jobData, SetOptions.merge())
            .addOnSuccessListener {
                Log.d(TAG, "Job ${job.title} synced to Firestore doc: $docId")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Job sync failed: ${e.message}")
            }
    }

    /**
     * Pull remote workers from Firestore and sync into local Room database.
     */
    fun pullWorkersFromFirestore(onResult: (List<WorkerEntity>) -> Unit) {
        val db = firestore ?: run {
            onResult(emptyList())
            return
        }

        db.collection(COLLECTION_WORKERS)
            .get()
            .addOnSuccessListener { querySnapshot ->
                val list = mutableListOf<WorkerEntity>()
                for (doc in querySnapshot.documents) {
                    try {
                        val worker = WorkerEntity(
                            id = doc.safeLong("id", 0L),
                            nameBn = doc.safeString("nameBn", ""),
                            nameEn = doc.safeString("nameEn", ""),
                            categoryId = doc.safeString("categoryId", "electrician"),
                            categoryTitleBn = doc.safeString("categoryTitleBn", "ইলেকট্রিশিয়ান"),
                            phone = doc.safeString("phone", ""),
                            area = doc.safeString("area", "ঢাকা"),
                            district = doc.safeString("district", "ঢাকা"),
                            experienceYears = doc.safeInt("experienceYears", 2),
                            hourlyRate = doc.safeInt("hourlyRate", 350),
                            rating = doc.safeFloat("rating", 4.8f),
                            reviewsCount = doc.safeInt("reviewsCount", 10),
                            completedJobsCount = doc.safeInt("completedJobsCount", 15),
                            bioBn = doc.safeString("bioBn", ""),
                            skillsBn = doc.safeString("skillsBn", ""),
                            isVerified = doc.safeBoolean("isVerified", true),
                            isOnline = doc.safeBoolean("isOnline", true),
                            avatarBgColorHex = doc.safeLong("avatarBgColorHex", 0xFF0A6847),
                            photoUri = doc.safeStringOrNull("photoUri")?.ifBlank { null },
                            ownerUid = doc.safeStringOrNull("ownerUid")?.ifBlank { null }
                        )
                        list.add(worker)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing worker doc: ${e.message}")
                    }
                }
                onResult(list)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error pulling workers from Firestore: ${e.message}")
                onResult(emptyList())
            }
    }

    /**
     * Pull remote job posts from Firestore.
     */
    fun pullJobsFromFirestore(onResult: (List<JobRequestEntity>) -> Unit) {
        val db = firestore ?: run {
            onResult(emptyList())
            return
        }

        db.collection(COLLECTION_JOBS)
            .get()
            .addOnSuccessListener { querySnapshot ->
                val list = mutableListOf<JobRequestEntity>()
                for (doc in querySnapshot.documents) {
                    try {
                        val assignedWorkerIdVal = doc.safeLongOrNull("assignedWorkerId")?.takeIf { it > 0 }
                        val assignedWorkerNameVal = doc.safeStringOrNull("assignedWorkerName")?.takeIf { it.isNotBlank() }
                        val assignedWorkerPhoneVal = doc.safeStringOrNull("assignedWorkerPhone")?.takeIf { it.isNotBlank() }

                        val job = JobRequestEntity(
                            id = doc.safeLong("id", 0L),
                            title = doc.safeString("title", ""),
                            categoryId = doc.safeString("categoryId", "general"),
                            categoryTitleBn = doc.safeString("categoryTitleBn", "সাধারণ সেবা"),
                            description = doc.safeString("description", ""),
                            clientName = doc.safeString("clientName", "গ্রাহক"),
                            clientPhone = doc.safeString("clientPhone", ""),
                            address = doc.safeString("address", ""),
                            area = doc.safeString("area", "ঢাকা"),
                            budget = doc.safeInt("budget", 500),
                            isUrgent = doc.safeBoolean("isUrgent", false),
                            scheduledDate = doc.safeString("scheduledDate", "আজ"),
                            scheduledTime = doc.safeString("scheduledTime", "এখনই"),
                            status = doc.safeString("status", "PENDING"),
                            assignedWorkerId = assignedWorkerIdVal,
                            assignedWorkerName = assignedWorkerNameVal,
                            assignedWorkerPhone = assignedWorkerPhoneVal,
                            assignedWorkerUid = doc.safeStringOrNull("assignedWorkerUid")?.ifBlank { null },
                            ratingGiven = doc.safeInt("ratingGiven", 0),
                            reviewGiven = doc.safeString("reviewGiven", ""),
                            ownerUid = doc.safeStringOrNull("ownerUid")?.ifBlank { null },
                            createdAtTimestamp = doc.safeLong("createdAtTimestamp", System.currentTimeMillis())
                        )
                        list.add(job)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing job doc: ${e.message}")
                    }
                }
                onResult(list)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error pulling jobs: ${e.message}")
                onResult(emptyList())
            }
    }

    fun listenWorkers(onResult: (List<WorkerEntity>) -> Unit, onError: (Exception) -> Unit = {}) =
        firestore?.collection(COLLECTION_WORKERS)?.addSnapshotListener { snapshot, error ->
            if (error != null) { onError(error); return@addSnapshotListener }
            val list = snapshot?.documents?.mapNotNull { doc ->
                try { WorkerEntity(
                    id = doc.safeLong("id", 0L), nameBn = doc.safeString("nameBn"), nameEn = doc.safeString("nameEn"),
                    categoryId = doc.safeString("categoryId", "general"), categoryTitleBn = doc.safeString("categoryTitleBn", "সাধারণ সেবা"),
                    phone = doc.safeString("phone"), area = doc.safeString("area", "ঢাকা"), district = doc.safeString("district", "ঢাকা"),
                    experienceYears = doc.safeInt("experienceYears", 0), hourlyRate = doc.safeInt("hourlyRate", 0),
                    rating = doc.safeFloat("rating", 0f), reviewsCount = doc.safeInt("reviewsCount", 0), completedJobsCount = doc.safeInt("completedJobsCount", 0),
                    bioBn = doc.safeString("bioBn"), skillsBn = doc.safeString("skillsBn"), isVerified = doc.safeBoolean("isVerified", false),
                    isOnline = doc.safeBoolean("isOnline", false), avatarBgColorHex = doc.safeLong("avatarBgColorHex", 0xFF0A6847),
                    photoUri = doc.safeStringOrNull("photoUri"), ownerUid = doc.safeStringOrNull("ownerUid")
                ) } catch (_: Exception) { null }
            } ?: emptyList()
            onResult(list)
        }

    fun listenJobs(onResult: (List<JobRequestEntity>) -> Unit, onError: (Exception) -> Unit = {}) =
        firestore?.collection(COLLECTION_JOBS)?.addSnapshotListener { snapshot, error ->
            if (error != null) { onError(error); return@addSnapshotListener }
            val list = snapshot?.documents?.mapNotNull { doc ->
                try { JobRequestEntity(
                    id = doc.safeLong("id", 0L), title = doc.safeString("title"), categoryId = doc.safeString("categoryId", "general"),
                    categoryTitleBn = doc.safeString("categoryTitleBn", "সাধারণ সেবা"), description = doc.safeString("description"),
                    clientName = doc.safeString("clientName", "গ্রাহক"), clientPhone = doc.safeString("clientPhone"), address = doc.safeString("address"),
                    area = doc.safeString("area", "ঢাকা"), budget = doc.safeInt("budget", 0), isUrgent = doc.safeBoolean("isUrgent", false),
                    scheduledDate = doc.safeString("scheduledDate"), scheduledTime = doc.safeString("scheduledTime"), status = doc.safeString("status", "PENDING"),
                    assignedWorkerId = doc.safeLongOrNull("assignedWorkerId")?.takeIf { it > 0 },
                    assignedWorkerName = doc.safeStringOrNull("assignedWorkerName"), assignedWorkerPhone = doc.safeStringOrNull("assignedWorkerPhone"),
                    assignedWorkerUid = doc.safeStringOrNull("assignedWorkerUid"), ratingGiven = doc.safeInt("ratingGiven", 0),
                    reviewGiven = doc.safeString("reviewGiven"), ownerUid = doc.safeStringOrNull("ownerUid"),
                    createdAtTimestamp = doc.safeLong("createdAtTimestamp", System.currentTimeMillis())
                ) } catch (_: Exception) { null }
            } ?: emptyList()
            onResult(list)
        }

    fun syncChatMessage(jobId: Long, message: ChatMessageEntity) {
        val db = firestore ?: return
        val data = hashMapOf<String, Any?>(
            "id" to message.id, "jobId" to jobId, "senderName" to message.senderName,
            "senderUid" to message.senderUid, "isClient" to message.isClient,
            "messageText" to message.messageText, "timestamp" to message.timestamp
        )
        val stableId = if (message.id > 0) message.id.toString() else "${message.senderUid.orEmpty()}_${message.timestamp}"
        db.collection(COLLECTION_JOBS).document(jobId.toString()).collection(COLLECTION_CHAT)
            .document(stableId)
            .set(data, SetOptions.merge())
    }

    fun listenChat(jobId: Long, onResult: (List<ChatMessageEntity>) -> Unit, onError: (Exception) -> Unit = {}) =
        firestore?.collection(COLLECTION_JOBS).document(jobId.toString()).collection(COLLECTION_CHAT)
            ?.orderBy("timestamp")?.addSnapshotListener { snapshot, error ->
                if (error != null) { onError(error); return@addSnapshotListener }
                onResult(snapshot?.documents?.mapNotNull { d ->
                    try { ChatMessageEntity(
                        id = d.safeLong("id", 0L), jobId = d.safeLong("jobId", jobId), senderName = d.safeString("senderName"),
                        isClient = d.safeBoolean("isClient", false), senderUid = d.safeStringOrNull("senderUid"),
                        messageText = d.safeString("messageText"), timestamp = d.safeLong("timestamp", System.currentTimeMillis())
                    ) } catch (_: Exception) { null }
                } ?: emptyList())
            }

    // --- Safe DocumentSnapshot parsing helpers to prevent ClassCastException ---
    private fun com.google.firebase.firestore.DocumentSnapshot.safeString(field: String, default: String = ""): String {
        val value = get(field) ?: return default
        return value.toString()
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.safeStringOrNull(field: String): String? {
        val value = get(field) ?: return null
        val str = value.toString()
        return if (str.isBlank()) null else str
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.safeInt(field: String, default: Int = 0): Int {
        val value = get(field) ?: return default
        return when (value) {
            is Number -> value.toInt()
            is String -> value.toDoubleOrNull()?.toInt() ?: default
            else -> default
        }
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.safeLong(field: String, default: Long = 0L): Long {
        val value = get(field) ?: return default
        return when (value) {
            is Number -> value.toLong()
            is String -> value.toDoubleOrNull()?.toLong() ?: default
            else -> default
        }
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.safeLongOrNull(field: String): Long? {
        val value = get(field) ?: return null
        return when (value) {
            is Number -> value.toLong()
            is String -> value.toDoubleOrNull()?.toLong()
            else -> null
        }
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.safeFloat(field: String, default: Float = 0f): Float {
        val value = get(field) ?: return default
        return when (value) {
            is Number -> value.toFloat()
            is String -> value.toFloatOrNull() ?: default
            else -> default
        }
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.safeBoolean(field: String, default: Boolean = false): Boolean {
        val value = get(field) ?: return default
        return when (value) {
            is Boolean -> value
            is String -> value.equals("true", ignoreCase = true)
            is Number -> value.toInt() != 0
            else -> default
        }
    }

    companion object {
        private const val TAG = "FirestoreSyncRepo"
        const val COLLECTION_USERS = "users"
        const val COLLECTION_WORKERS = "workers"
        const val COLLECTION_JOBS = "job_posts"
        const val COLLECTION_DISTRICTS = "districts"
        const val COLLECTION_CHAT = "chat_messages"
    }
}
