package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Worker / Artisan profile entity in KajBondhu platform
 */
@Entity(tableName = "workers")
data class WorkerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nameBn: String,
    val nameEn: String,
    val categoryId: String,
    val categoryTitleBn: String,
    val phone: String,
    val area: String,
    val district: String = "ঢাকা",
    val experienceYears: Int,
    val hourlyRate: Int,
    val rating: Float,
    val reviewsCount: Int,
    val completedJobsCount: Int,
    val bioBn: String,
    val skillsBn: String, // Comma separated skills
    val isVerified: Boolean = true,
    val isOnline: Boolean = true,
    val avatarBgColorHex: Long = 0xFF0A6847,
    val photoUri: String? = null,
    val ownerUid: String? = null
)

/**
 * Job request or booking placed by customer
 */
@Entity(tableName = "jobs")
data class JobRequestEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val categoryId: String,
    val categoryTitleBn: String,
    val description: String,
    val clientName: String,
    val clientPhone: String,
    val address: String,
    val area: String,
    val budget: Int,
    val isUrgent: Boolean = false,
    val scheduledDate: String,
    val scheduledTime: String,
    val status: String, // PENDING, ACCEPTED, IN_PROGRESS, COMPLETED, CANCELLED
    val assignedWorkerId: Long? = null,
    val assignedWorkerName: String? = null,
    val assignedWorkerPhone: String? = null,
    val assignedWorkerUid: String? = null,
    val ratingGiven: Int = 0,
    val reviewGiven: String = "",
    val ownerUid: String? = null,
    val createdAtTimestamp: Long = System.currentTimeMillis()
)

/**
 * Chat message between client and worker
 */
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val jobId: Long,
    val senderName: String,
    val isClient: Boolean,
    val senderUid: String? = null,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Financial and wallet transaction history
 */
@Entity(tableName = "wallet_transactions")
data class WalletTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val titleBn: String,
    val amount: Int,
    val isCredit: Boolean, // true = added/earned, false = payout/paid
    val paymentMethod: String, // bKash, Nagad, Cash, Bank
    val dateString: String,
    val referenceJobId: Long? = null,
    val ownerUid: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val externalId: String? = null
)

/**
 * Categories model with icons and meta
 */
data class ServiceCategory(
    val id: String,
    val titleBn: String,
    val titleEn: String,
    val iconEmoji: String,
    val descriptionBn: String,
    val startingPrice: Int,
    val popularSkills: List<String>
)
