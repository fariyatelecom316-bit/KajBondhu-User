package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ChatMessageEntity
import com.example.data.model.JobRequestEntity
import com.example.data.model.WalletTransactionEntity
import com.example.data.model.WorkerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkerDao {
    @Query("SELECT * FROM workers ORDER BY rating DESC, completedJobsCount DESC")
    fun getAllWorkers(): Flow<List<WorkerEntity>>

    @Query("SELECT * FROM workers WHERE categoryId = :catId ORDER BY rating DESC")
    fun getWorkersByCategory(catId: String): Flow<List<WorkerEntity>>

    @Query("SELECT * FROM workers WHERE id = :workerId LIMIT 1")
    fun getWorkerById(workerId: Long): Flow<WorkerEntity?>

    @Query("SELECT * FROM workers WHERE nameBn LIKE '%' || :query || '%' OR skillsBn LIKE '%' || :query || '%' OR area LIKE '%' || :query || '%'")
    fun searchWorkers(query: String): Flow<List<WorkerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorker(worker: WorkerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkers(workers: List<WorkerEntity>)

    @Update
    suspend fun updateWorker(worker: WorkerEntity)

    @Query("SELECT COUNT(*) FROM workers")
    suspend fun getWorkerCount(): Int
}

@Dao
interface JobDao {
    @Query("SELECT * FROM jobs ORDER BY createdAtTimestamp DESC")
    fun getAllJobs(): Flow<List<JobRequestEntity>>

    @Query("SELECT * FROM jobs WHERE status = :status ORDER BY createdAtTimestamp DESC")
    fun getJobsByStatus(status: String): Flow<List<JobRequestEntity>>

    @Query("SELECT * FROM jobs WHERE id = :jobId LIMIT 1")
    fun getJobById(jobId: Long): Flow<JobRequestEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: JobRequestEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJobs(jobs: List<JobRequestEntity>)

    @Update
    suspend fun updateJob(job: JobRequestEntity)

    @Query("UPDATE jobs SET status = :status WHERE id = :jobId")
    suspend fun updateStatus(jobId: Long, status: String)

    @Query("UPDATE jobs SET status = :status, assignedWorkerId = :workerId, assignedWorkerName = :workerName, assignedWorkerPhone = :workerPhone, assignedWorkerUid = :workerUid WHERE id = :jobId")
    suspend fun assignWorker(jobId: Long, status: String, workerId: Long, workerName: String, workerPhone: String, workerUid: String)

    @Query("UPDATE jobs SET ratingGiven = :rating, reviewGiven = :review WHERE id = :jobId")
    suspend fun submitReview(jobId: Long, rating: Int, review: String)

    @Query("DELETE FROM jobs WHERE id = :jobId")
    suspend fun deleteJob(jobId: Long)

    @Query("SELECT COUNT(*) FROM jobs")
    suspend fun getJobCount(): Int
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages WHERE jobId = :jobId ORDER BY timestamp ASC")
    fun getMessagesForJob(jobId: Long): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(msg: ChatMessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(msgs: List<ChatMessageEntity>)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallet_transactions WHERE ownerUid = :ownerUid ORDER BY timestamp DESC")
    fun getTransactionsForOwner(ownerUid: String): Flow<List<WalletTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: WalletTransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(txs: List<WalletTransactionEntity>)

    @Query("SELECT COUNT(*) FROM wallet_transactions")
    suspend fun getTransactionCount(): Int
}
