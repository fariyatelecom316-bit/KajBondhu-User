package com.example.data.local

import com.example.data.model.ServiceCategory

object SeedData {
    val categories = listOf(
        ServiceCategory(
            id = "electrician",
            titleBn = "ইলেকট্রিশিয়ান",
            titleEn = "Electrician",
            iconEmoji = "⚡",
            descriptionBn = "ফ্যান, লাইট, শর্ট সার্কিট, ওয়্যারিং মেরামত ও স্থাপন",
            startingPrice = 350,
            popularSkills = listOf("ফ্যান ফিটিং", "ওয়্যারিং", "সুইচ বোর্ড", "ডিবি বোর্ড", "আইপিএস")
        ),
        ServiceCategory(
            id = "plumber",
            titleBn = "প্লাম্বার (স্যানিটারি)",
            titleEn = "Plumber",
            iconEmoji = "🔧",
            descriptionBn = "পানির লাইন, কল, বেসিন, কমোড, পাইপ লিক মেরামত",
            startingPrice = 400,
            popularSkills = listOf("পাইপ ফিটিং", "বেসিন মেরামত", "ট্যাপ মেরামত", "লিক সিলিং", "কমোড ফিটিং")
        ),
        ServiceCategory(
            id = "ac_fridge",
            titleBn = "এসি ও ফ্রিজ টেকনিশিয়ান",
            titleEn = "AC & Appliance",
            iconEmoji = "❄️",
            descriptionBn = "এসি সার্ভিসিং, গ্যাস চার্জ, ফ্রিজ কুলিং সমস্যা সমাধান",
            startingPrice = 800,
            popularSkills = listOf("মাস্টার সার্ভিস", "গ্যাস রিফিল", "কুলিং সমস্যা", "ইনভার্টার মেরামত", "ইনস্টলেশন")
        ),
        ServiceCategory(
            id = "cleaning",
            titleBn = "বাসা ও অফিস ক্লিনিং",
            titleEn = "Home Cleaning",
            iconEmoji = "🧹",
            descriptionBn = "ডিপ হোম ক্লিনিং, সোফা ও কার্পেট ওয়াশ, কিচেন ক্লিনিং",
            startingPrice = 600,
            popularSkills = listOf("সোফা ওয়াশ", "কিচেন ডিপ ক্লিন", "বাথরুম ক্লিন", "কার্পেট ওয়াশ", "ফ্লোর পলিশ")
        ),
        ServiceCategory(
            id = "painter",
            titleBn = "রং মিস্ত্রি (পেইন্টার)",
            titleEn = "House Painter",
            iconEmoji = "🎨",
            descriptionBn = "ওয়াল পেইন্টিং, ড্যাম ট্রিটমেন্ট, পুটিং ও পলিশ কাজ",
            startingPrice = 500,
            popularSkills = listOf("ইন্টেরিয়র পেইন্ট", "ওয়াল পুটিং", "ড্যাম সিলিং", "বার্নিশ")
        ),
        ServiceCategory(
            id = "carpenter",
            titleBn = "কাঠ মিস্ত্রি (কার্পেন্টার)",
            titleEn = "Carpenter",
            iconEmoji = "🪚",
            descriptionBn = "দরজা, লক, ক্যাবিনেট, খাট, সোফা তৈরি ও মেরামত",
            startingPrice = 450,
            popularSkills = listOf("দরজা লক ফিটিং", "ক্যাবিনেট", "খাট মেরামত", "ড্রয়ার চ্যানেল", "ফার্নিচার পলিশ")
        ),
        ServiceCategory(
            id = "shifting",
            titleBn = "বাসা বদল ও লেবার",
            titleEn = "Moving & Labor",
            iconEmoji = "📦",
            descriptionBn = "নিরাপদ বাসা শিফটিং, মালামাল লোডিং ও দক্ষ শ্রমিক",
            startingPrice = 700,
            popularSkills = listOf("বাসা শিফটিং", "প্যাকিং", "লোড-আনলোড", "ভারী ফার্নিচার মুভ")
        ),
        ServiceCategory(
            id = "driver",
            titleBn = "ব্যক্তিগত ও অন-ডিমান্ড ড্রাইভার",
            titleEn = "Driver",
            iconEmoji = "🚗",
            descriptionBn = "অভিজ্ঞ ও যাচাইকৃত ডে-ড্রাইভার ও ট্রিপ ড্রাইভার",
            startingPrice = 600,
            popularSkills = listOf("সিটি ড্রাইভ", "হাইওয়ে ড্রাইভ", "ম্যানুয়াল গিয়ার", "অটো গিয়ার")
        ),
        ServiceCategory(
            id = "mason",
            titleBn = "রাজমিস্ত্রি (নির্মাণ কাজ)",
            titleEn = "Mason",
            iconEmoji = "🧱",
            descriptionBn = "ইট গাঁথুনি, প্লাস্টার, দেয়াল মেরামত ও সংস্কার কাজ",
            startingPrice = 550,
            popularSkills = listOf("গাঁথুনি", "প্লাস্টার", "দেয়াল মেরামত", "ছাদ ঢালাই", "ভেঙ্গে ফেলা")
        ),
        ServiceCategory(
            id = "tile_mason",
            titleBn = "টাইলস ও মার্বেল মিস্ত্রি",
            titleEn = "Tile Mason",
            iconEmoji = "📐",
            descriptionBn = "ফ্লোর ও ওয়াল টাইলস ফিটিং, গ্রাউটিং ও মার্বেল পলিশ",
            startingPrice = 500,
            popularSkills = listOf("ফ্লোর টাইলস", "ওয়াল টাইলস", "টাইলস গ্রাউটিং", "মার্বেল কাটিং", "স্ক্র্যাচ রিমুভ")
        )
    )

}
