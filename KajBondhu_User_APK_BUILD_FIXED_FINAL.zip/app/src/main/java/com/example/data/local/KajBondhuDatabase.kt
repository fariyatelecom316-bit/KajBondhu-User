package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ChatMessageEntity
import com.example.data.model.JobRequestEntity
import com.example.data.model.WalletTransactionEntity
import com.example.data.model.WorkerEntity

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE workers ADD COLUMN ownerUid TEXT DEFAULT NULL")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE wallet_transactions ADD COLUMN ownerUid TEXT DEFAULT NULL")

        // Remove only the known seed/demo records from older app installs.
        db.execSQL("DELETE FROM workers WHERE phone IN ('01712345678','01823456789','01934567890','01645678901','01556789012','01798765432','01811223344')")
        db.execSQL("DELETE FROM jobs WHERE clientPhone IN ('01700112233','01855667788','01999887766','01611223344','01788990011')")
        db.execSQL("DELETE FROM wallet_transactions WHERE id IN (1,2,3)")
        db.execSQL("DELETE FROM chat_messages WHERE id IN (1,2,3)")
    }
}


val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE jobs ADD COLUMN assignedWorkerUid TEXT DEFAULT NULL")
        db.execSQL("ALTER TABLE chat_messages ADD COLUMN senderUid TEXT DEFAULT NULL")
    }
}

val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE wallet_transactions ADD COLUMN externalId TEXT DEFAULT NULL")
    }
}

@Database(
    entities = [
        WorkerEntity::class,
        JobRequestEntity::class,
        ChatMessageEntity::class,
        WalletTransactionEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class KajBondhuDatabase : RoomDatabase() {
    abstract fun workerDao(): WorkerDao
    abstract fun jobDao(): JobDao
    abstract fun chatDao(): ChatDao
    abstract fun walletDao(): WalletDao

    companion object {
        @Volatile
        private var INSTANCE: KajBondhuDatabase? = null

        fun getDatabase(context: Context): KajBondhuDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KajBondhuDatabase::class.java,
                    "kajbondhu_database"
                )
                    .addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
