package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.BuildConfig
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

class PaymentGatewayRepository(private val context: Context) {
    data class Checkout(val orderId: String, val paymentId: String?, val checkoutUrl: String?)

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val baseUrl: String
        get() = BuildConfig.PAYMENT_BACKEND_URL.trim().trimEnd('/')

    suspend fun createCheckout(amount: Int, method: String): Result<Checkout> = withContext(Dispatchers.IO) {
        runCatching {
            require(baseUrl.isNotBlank()) { "A fizetési szerver még nincs beállítva." }
            val user = FirebaseAuth.getInstance().currentUser ?: error("Google-fiókkal be kell jelentkezni.")
            val token = user.getIdToken(false).awaitToken()
            val path = when (method.lowercase()) {
                "bkash" -> "/v1/payments/bkash/create"
                "nagad" -> "/v1/payments/nagad/create"
                "rocket" -> "/v1/payments/rocket/create"
                else -> error("অজানা পেমেন্ট মাধ্যম")
            }
            val body = JSONObject().put("amount", amount).toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(baseUrl + path)
                .header("Authorization", "Bearer $token")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(text) }.getOrNull()
                if (!response.isSuccessful) error(json?.optString("error").orEmpty().ifBlank { "Payment server error" })
                val orderId = json?.optString("orderId").orEmpty()
                if (orderId.isBlank()) error("Payment order তৈরি হয়নি")
                val url = when (method.lowercase()) {
                    "bkash" -> json.optString("bkashURL").ifBlank { null }
                    "nagad" -> json.optString("nagadURL").ifBlank { null }
                    else -> json.optString("rocketURL").ifBlank { null }
                }
                Checkout(orderId, json.optString("paymentID").ifBlank { json.optString("paymentId").ifBlank { null } }, url)
            }
        }
    }

    suspend fun executeBkash(orderId: String, paymentId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            require(baseUrl.isNotBlank()) { "Payment backend URL not configured" }
            val user = FirebaseAuth.getInstance().currentUser ?: error("Google-faq দিয়ে লগইন করুন")
            val token = user.getIdToken(false).awaitToken()
            val body = JSONObject().put("orderId", orderId).put("paymentID", paymentId).toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(baseUrl + "/v1/payments/bkash/execute")
                .header("Authorization", "Bearer $token").post(body).build()
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(text) }.getOrNull()
                if (!response.isSuccessful) error(json?.optString("error").orEmpty().ifBlank { "Payment verification failed" })
                json?.optString("status") == "PAID"
            }
        }
    }

    fun openCheckout(url: String): Result<Unit> = runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.auth.GetTokenResult>.awaitToken(): String =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            addOnSuccessListener { result -> cont.resume(result.token.orEmpty()) {} }
            addOnFailureListener { error -> cont.resumeWith(Result.failure(error)) }
        }
}
