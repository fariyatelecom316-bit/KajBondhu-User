# GitHub-এ আপলোড ও Build নির্দেশনা

## ১. GitHub repository তৈরি
এই পুরো ফোল্ডারের সব ফাইল GitHub repository-তে আপলোড করুন। ZIP ফাইলটি সরাসরি release হিসেবে নয়, আগে Extract করে ফাইলগুলো repository-এর root-এ দিন।

## ২. GitHub Secrets
Repository → Settings → Secrets and variables → Actions → New repository secret:

- `GEMINI_API_KEY` — Gemini API key (প্রয়োজন হলে)
- User App-এর জন্য `PAYMENT_BACKEND_URL` — আপনার deployed payment backend-এর HTTPS URL

API key বা private payment secret কখনো source code-এ লিখবেন না।

## ৩. Build চালানো
Actions → Android Build → Run workflow চাপুন। Build শেষ হলে Artifacts থেকে APK/AAB পাওয়া যাবে।

## ৪. Google Play
Google Play Console-এ নতুন অ্যাপের জন্য AAB ব্যবহার করুন। Play App Signing চালু করুন। পরবর্তী update-এর আগে `versionCode` অবশ্যই বাড়াতে হবে।

> গুরুত্বপূর্ণ: এই workflow build তৈরি করে। Google Play-এর final signing/upload key Play Console-এর মাধ্যমে নিরাপদে পরিচালনা করতে হবে।
