import express from 'express';
import fs from 'fs';
import crypto from 'crypto';
import admin from 'firebase-admin';

const app = express();
app.use(express.json());

const port = Number(process.env.PORT || 8080);
const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
if (!serviceAccountPath || !fs.existsSync(serviceAccountPath)) {
  console.error('FIREBASE_SERVICE_ACCOUNT_JSON is missing or points to a missing file.');
  process.exit(1);
}
admin.initializeApp({ credential: admin.credential.cert(JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'))) });
const db = admin.firestore();

const cfg = {
  bkash: {
    baseUrl: process.env.BKASH_BASE_URL,
    username: process.env.BKASH_USERNAME,
    password: process.env.BKASH_PASSWORD,
    appKey: process.env.BKASH_APP_KEY,
    appSecret: process.env.BKASH_APP_SECRET,
  },
  rocket: {
    createUrl: process.env.ROCKET_CREATE_URL,
    verifyUrl: process.env.ROCKET_VERIFY_URL,
    merchantId: process.env.ROCKET_MERCHANT_ID,
    apiKey: process.env.ROCKET_API_KEY,
    callbackUrl: process.env.ROCKET_CALLBACK_URL,
  },
  nagad: {
    baseUrl: process.env.NAGAD_BASE_URL,
    merchantId: process.env.NAGAD_MERCHANT_ID,
    merchantNumber: process.env.NAGAD_MERCHANT_NUMBER,
    merchantPrivateKey: process.env.NAGAD_MERCHANT_PRIVATE_KEY,
    pgPublicKey: process.env.NAGAD_PG_PUBLIC_KEY,
    callbackUrl: process.env.NAGAD_CALLBACK_URL,
    apiVersion: process.env.NAGAD_API_VERSION || 'v-0.2.0',
    clientType: process.env.NAGAD_CLIENT_TYPE || 'MOBILE_WEB',
  },
};

function requireValues(group, keys) {
  for (const k of keys) if (!group[k]) throw new Error(`Missing payment configuration: ${k}`);
}

async function firebaseUser(req) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) throw new Error('Missing Firebase ID token');
  return admin.auth().verifyIdToken(h.slice(7));
}

async function bkashToken() {
  requireValues(cfg.bkash, ['baseUrl','username','password','appKey','appSecret']);
  const r = await fetch(`${cfg.bkash.baseUrl}/checkout/token/grant`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json', username: cfg.bkash.username, password: cfg.bkash.password },
    body: JSON.stringify({ app_key: cfg.bkash.appKey, app_secret: cfg.bkash.appSecret })
  });
  const data = await r.json();
  if (!r.ok || !data.id_token) throw new Error(`bKash token error: ${JSON.stringify(data)}`);
  return data.id_token;
}

function asPem(key, type) {
  if (!key) return key;
  if (key.includes('BEGIN')) return key.replace(/\\n/g, '\n');
  const label = type === 'private' ? 'PRIVATE KEY' : 'PUBLIC KEY';
  return `-----BEGIN ${label}-----\n${key.replace(/\s+/g, '').match(/.{1,64}/g).join('\n')}\n-----END ${label}-----`;
}
function nagadEncrypt(plain) {
  const key = asPem(cfg.nagad.pgPublicKey, 'public');
  return crypto.publicEncrypt({ key, padding: crypto.constants.RSA_PKCS1_PADDING }, Buffer.from(plain, 'utf8')).toString('base64');
}
function nagadDecrypt(ciphertext) {
  const key = asPem(cfg.nagad.merchantPrivateKey, 'private');
  return crypto.privateDecrypt({ key, padding: crypto.constants.RSA_PKCS1_PADDING }, Buffer.from(ciphertext, 'base64')).toString('utf8');
}
function nagadSign(plain) {
  const key = asPem(cfg.nagad.merchantPrivateKey, 'private');
  return crypto.createSign('RSA-SHA256').update(plain).sign(key, 'base64');
}
function nagadHeaders() {
  return { 'Content-Type': 'application/json', Accept: 'application/json', 'X-KM-Api-Version': cfg.nagad.apiVersion, 'X-KM-Client-Type': cfg.nagad.clientType };
}
function randomChallenge() { return crypto.randomBytes(20).toString('hex').toUpperCase(); }
function safeInvoice(id) { return `KB${id.replace(/[^A-Za-z0-9]/g, '').slice(0, 18)}`; }



async function rocketCreate(amount, orderId) {
  requireValues(cfg.rocket, ['createUrl','merchantId','apiKey','callbackUrl']);
  const invoice = safeInvoice(orderId);
  const payload = {
    merchantId: cfg.rocket.merchantId,
    invoice,
    orderId,
    amount: Number(amount).toFixed(2),
    currency: 'BDT',
    callbackUrl: cfg.rocket.callbackUrl,
  };
  const r = await fetch(cfg.rocket.createUrl, {
    method: 'POST',
    headers: { 'Content-Type':'application/json', Accept:'application/json', Authorization:`Bearer ${cfg.rocket.apiKey}` },
    body: JSON.stringify(payload),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(`Rocket create error: ${JSON.stringify(data)}`);
  const paymentId = data.paymentId || data.paymentID || data.transactionId || data.referenceId || data.paymentReferenceId;
  const checkoutUrl = data.checkoutUrl || data.paymentUrl || data.redirectUrl || data.url;
  if (!paymentId || !checkoutUrl) throw new Error('Rocket create response must contain payment/reference ID and checkout URL');
  return { invoice, paymentId, checkoutUrl };
}

async function rocketVerify(paymentId, orderId) {
  requireValues(cfg.rocket, ['verifyUrl','merchantId','apiKey']);
  const r = await fetch(cfg.rocket.verifyUrl, {
    method: 'POST',
    headers: { 'Content-Type':'application/json', Accept:'application/json', Authorization:`Bearer ${cfg.rocket.apiKey}` },
    body: JSON.stringify({ merchantId: cfg.rocket.merchantId, orderId, paymentId }),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(`Rocket verify error: ${JSON.stringify(data)}`);
  return data;
}

function rocketPaid(data, expectedAmount) {
  const status = String(data.status || data.transactionStatus || data.paymentStatus || '').toUpperCase();
  const paid = ['SUCCESS','SUCCESSFUL','COMPLETED','PAID','000'].includes(status) || String(data.statusCode || '') === '000';
  const verifiedAmount = Number(data.amount ?? data.paidAmount ?? data.transactionAmount);
  return paid && Number.isFinite(verifiedAmount) && verifiedAmount === Number(expectedAmount);
}

async function nagadCreate(amount, orderId) {
  requireValues(cfg.nagad, ['baseUrl','merchantId','merchantPrivateKey','pgPublicKey','callbackUrl']);
  const invoice = safeInvoice(orderId);
  const dateTime = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0,14);
  const initSensitive = JSON.stringify({ merchantId: cfg.nagad.merchantId, datetime: dateTime, orderId: invoice, challenge: randomChallenge() });
  const url = `${cfg.nagad.baseUrl.replace(/\/$/,'')}/check-out/initialize/${encodeURIComponent(cfg.nagad.merchantId)}/${encodeURIComponent(invoice)}`;
  const r = await fetch(url, { method: 'POST', headers: nagadHeaders(), body: JSON.stringify({ accountNumber: cfg.nagad.merchantNumber || undefined, dateTime, sensitiveData: nagadEncrypt(initSensitive), signature: nagadSign(initSensitive) }) });
  const data = await r.json();
  if (!r.ok || !data.sensitiveData) throw new Error(`Nagad initialize error: ${JSON.stringify(data)}`);
  const init = JSON.parse(nagadDecrypt(data.sensitiveData));
  if (!init.paymentReferenceId || !init.challenge) throw new Error('Nagad initialize response missing paymentReferenceId/challenge');

  const orderSensitive = JSON.stringify({ merchantId: cfg.nagad.merchantId, orderId: invoice, currencyCode: '050', amount: Number(amount).toFixed(2), challenge: init.challenge });
  const completeUrl = `${cfg.nagad.baseUrl.replace(/\/$/,'')}/check-out/complete/${encodeURIComponent(init.paymentReferenceId)}`;
  const c = await fetch(completeUrl, { method: 'POST', headers: nagadHeaders(), body: JSON.stringify({ sensitiveData: nagadEncrypt(orderSensitive), signature: nagadSign(orderSensitive), merchantCallbackURL: cfg.nagad.callbackUrl }) });
  const complete = await c.json();
  if (!c.ok || String(complete.status).toLowerCase() !== 'success' || !complete.callBackUrl) throw new Error(`Nagad complete error: ${JSON.stringify(complete)}`);
  return { invoice, paymentReferenceId: init.paymentReferenceId, checkoutUrl: complete.callBackUrl };
}

async function nagadVerify(paymentRefId) {
  requireValues(cfg.nagad, ['baseUrl','merchantId','merchantPrivateKey','pgPublicKey']);
  const url = `${cfg.nagad.baseUrl.replace(/\/$/,'')}/verify/payment/${encodeURIComponent(paymentRefId)}`;
  const r = await fetch(url, { method: 'GET', headers: nagadHeaders() });
  const data = await r.json();
  if (!r.ok) throw new Error(`Nagad verify error: ${JSON.stringify(data)}`);
  return data;
}

async function creditVerifiedOrder(ref, order, method, trxID) {
  const ledgerRef = db.collection('wallet_ledger').doc(ref.id);
  await db.runTransaction(async tx => {
    const current = await tx.get(ref);
    const ledger = await tx.get(ledgerRef);
    if (!current.exists) throw new Error('Order not found');
    if (current.data().status === 'PAID' || ledger.exists) return;
    tx.update(ref, { status: 'PAID', trxID: trxID || null, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    tx.set(ledgerRef, { ownerUid: order.ownerUid, orderId: ref.id, amount: order.amount, type: 'DEPOSIT', method, trxID: trxID || null, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  });
}

app.get('/health', (_, res) => res.json({ ok: true }));

app.post('/v1/payments/bkash/create', async (req, res) => {
  try {
    const user = await firebaseUser(req); const amount = Number(req.body.amount);
    if (!Number.isFinite(amount) || amount < 10 || amount > 100000) return res.status(400).json({ error: 'Invalid amount' });
    const orderRef = db.collection('payment_orders').doc(); const invoice = `KB-${orderRef.id.slice(0,20)}`;
    await orderRef.set({ ownerUid:user.uid, amount, currency:'BDT', method:'bKash', status:'CREATED', invoice, createdAt:admin.firestore.FieldValue.serverTimestamp() });
    const token = await bkashToken();
    const r = await fetch(`${cfg.bkash.baseUrl}/checkout/payment/create`, { method:'POST', headers:{'Content-Type':'application/json',Accept:'application/json',authorization:token,'x-app-key':cfg.bkash.appKey}, body:JSON.stringify({amount:amount.toFixed(2),intent:'sale',currency:'BDT',merchantInvoiceNumber:invoice}) });
    const data = await r.json(); if (!r.ok || !data.paymentID) throw new Error(`bKash create error: ${JSON.stringify(data)}`);
    await orderRef.update({paymentID:data.paymentID,status:'PAYMENT_CREATED'}); res.json({orderId:orderRef.id,paymentID:data.paymentID,bkashURL:data.bkashURL||data.paymentUrl||null});
  } catch(e){ console.error(e); res.status(500).json({error:'Payment creation failed'}); }
});

app.post('/v1/payments/bkash/execute', async (req, res) => {
  try {
    const user=await firebaseUser(req); const {orderId,paymentID}=req.body; if(!orderId||!paymentID)return res.status(400).json({error:'Missing orderId/paymentID'});
    const ref=db.collection('payment_orders').doc(orderId), snap=await ref.get(); if(!snap.exists||snap.data().ownerUid!==user.uid||snap.data().paymentID!==paymentID)return res.status(403).json({error:'Order ownership mismatch'});
    if(snap.data().status==='PAID')return res.json({ok:true,status:'PAID',trxID:snap.data().trxID});
    const token=await bkashToken(); const r=await fetch(`${cfg.bkash.baseUrl}/checkout/payment/execute`,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json',authorization:token,'x-app-key':cfg.bkash.appKey},body:JSON.stringify({paymentID})});
    const data=await r.json(); if(!r.ok)throw new Error(`bKash execute error: ${JSON.stringify(data)}`); const paid=['COMPLETED','SUCCESS'].includes(String(data.transactionStatus||'').toUpperCase());
    if(paid)await creditVerifiedOrder(ref,snap.data(),'bKash',data.trxID); else await ref.update({status:'FAILED',trxID:data.trxID||null,gatewayResponse:data,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
    res.json({ok:paid,status:paid?'PAID':'FAILED',trxID:data.trxID||null});
  }catch(e){console.error(e);res.status(500).json({error:'Payment execution failed'});}
});

app.post('/v1/payments/nagad/create', async (req,res)=>{
  try {
    const user=await firebaseUser(req); const amount=Number(req.body.amount);
    if(!Number.isFinite(amount)||amount<10||amount>100000)return res.status(400).json({error:'Invalid amount'});
    const ref=db.collection('payment_orders').doc();
    await ref.set({ownerUid:user.uid,amount,currency:'BDT',method:'Nagad',status:'CREATED',createdAt:admin.firestore.FieldValue.serverTimestamp()});
    const p=await nagadCreate(amount,ref.id);
    await ref.update({invoice:p.invoice,paymentReferenceId:p.paymentReferenceId,status:'PAYMENT_CREATED'});
    res.json({orderId:ref.id,paymentReferenceId:p.paymentReferenceId,nagadURL:p.checkoutUrl});
  }catch(e){console.error(e);res.status(500).json({error:'Nagad payment creation failed'});}
});

// Nagad redirects here after checkout. Never trust the callback alone: verify with Nagad first.
app.get('/v1/payments/nagad/callback', async (req,res)=>{
  try {
    const orderId=String(req.query.order_id||''); const paymentRefId=String(req.query.payment_ref_id||'');
    if(!orderId||!paymentRefId)return res.status(400).send('Missing payment information');
    const ref=db.collection('payment_orders').doc(orderId); const snap=await ref.get();
    if(!snap.exists||snap.data().paymentReferenceId!==paymentRefId)return res.status(403).send('Order mismatch');
    const verified=await nagadVerify(paymentRefId);
    const paid=String(verified.status||'').toLowerCase()==='success' || String(verified.statusCode||'')==='000';
    const amountMatches=Number(verified.amount)===Number(snap.data().amount);
    if(paid&&amountMatches) await creditVerifiedOrder(ref,snap.data(),'Nagad',verified.issuerPaymentRefNo||verified.issuerPaymentRef||paymentRefId);
    else await ref.update({status:'FAILED',gatewayResponse:verified,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
    res.redirect(`${process.env.PAYMENT_RESULT_URL||'https://example.com/payment-result'}?orderId=${encodeURIComponent(orderId)}&status=${paid&&amountMatches?'success':'failed'}`);
  }catch(e){console.error(e);res.status(500).send('Payment verification failed');}
});

app.post('/v1/payments/nagad/verify', async (req,res)=>{
  try {
    const user=await firebaseUser(req); const {orderId}=req.body; if(!orderId)return res.status(400).json({error:'Missing orderId'});
    const ref=db.collection('payment_orders').doc(orderId), snap=await ref.get(); if(!snap.exists||snap.data().ownerUid!==user.uid||snap.data().method!=='Nagad')return res.status(403).json({error:'Order ownership mismatch'});
    if(snap.data().status==='PAID')return res.json({ok:true,status:'PAID',trxID:snap.data().trxID});
    const verified=await nagadVerify(snap.data().paymentReferenceId); const paid=String(verified.status||'').toLowerCase()==='success'||String(verified.statusCode||'')==='000'; const amountMatches=Number(verified.amount)===Number(snap.data().amount);
    if(paid&&amountMatches)await creditVerifiedOrder(ref,snap.data(),'Nagad',verified.issuerPaymentRefNo||verified.issuerPaymentRef||snap.data().paymentReferenceId);
    res.json({ok:paid&&amountMatches,status:paid&&amountMatches?'PAID':'PENDING',trxID:verified.issuerPaymentRefNo||verified.issuerPaymentRef||null});
  }catch(e){console.error(e);res.status(500).json({error:'Nagad verification failed'});}
});



app.post('/v1/payments/rocket/create', async (req,res)=>{
  try {
    const user=await firebaseUser(req); const amount=Number(req.body.amount);
    if(!Number.isFinite(amount)||amount<10||amount>100000)return res.status(400).json({error:'Invalid amount'});
    const ref=db.collection('payment_orders').doc();
    await ref.set({ownerUid:user.uid,amount,currency:'BDT',method:'Rocket',status:'CREATED',createdAt:admin.firestore.FieldValue.serverTimestamp()});
    const p=await rocketCreate(amount,ref.id);
    await ref.update({invoice:p.invoice,paymentId:p.paymentId,status:'PAYMENT_CREATED'});
    res.json({orderId:ref.id,paymentId:p.paymentId,rocketURL:p.checkoutUrl});
  }catch(e){console.error(e);res.status(500).json({error:'Rocket payment creation failed'});}
});

app.get('/v1/payments/rocket/callback', async (req,res)=>{
  try {
    const orderId=String(req.query.order_id||req.query.orderId||'');
    const paymentId=String(req.query.payment_id||req.query.paymentId||req.query.referenceId||'');
    if(!orderId||!paymentId)return res.status(400).send('Missing payment information');
    const ref=db.collection('payment_orders').doc(orderId); const snap=await ref.get();
    if(!snap.exists||snap.data().method!=='Rocket'||snap.data().paymentId!==paymentId)return res.status(403).send('Order mismatch');
    const verified=await rocketVerify(paymentId,orderId);
    const paid=rocketPaid(verified,snap.data().amount);
    if(paid) await creditVerifiedOrder(ref,snap.data(),'Rocket',verified.trxID||verified.transactionId||paymentId);
    else await ref.update({status:'FAILED',gatewayResponse:verified,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
    res.redirect(`${process.env.PAYMENT_RESULT_URL||'https://example.com/payment-result'}?orderId=${encodeURIComponent(orderId)}&status=${paid?'success':'failed'}`);
  }catch(e){console.error(e);res.status(500).send('Rocket payment verification failed');}
});

app.post('/v1/payments/rocket/verify', async (req,res)=>{
  try {
    const user=await firebaseUser(req); const {orderId}=req.body; if(!orderId)return res.status(400).json({error:'Missing orderId'});
    const ref=db.collection('payment_orders').doc(orderId), snap=await ref.get();
    if(!snap.exists||snap.data().ownerUid!==user.uid||snap.data().method!=='Rocket')return res.status(403).json({error:'Order ownership mismatch'});
    if(snap.data().status==='PAID')return res.json({ok:true,status:'PAID',trxID:snap.data().trxID});
    const verified=await rocketVerify(snap.data().paymentId,orderId); const paid=rocketPaid(verified,snap.data().amount);
    if(paid)await creditVerifiedOrder(ref,snap.data(),'Rocket',verified.trxID||verified.transactionId||snap.data().paymentId);
    res.json({ok:paid,status:paid?'PAID':'PENDING',trxID:verified.trxID||verified.transactionId||null});
  }catch(e){console.error(e);res.status(500).json({error:'Rocket verification failed'});}
});

app.listen(port,()=>console.log(`KajBondhu payment backend listening on ${port}`));
