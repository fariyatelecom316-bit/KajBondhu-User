# KajBondhu real-payment backend

This backend keeps bKash, Nagad and Rocket merchant secrets off the Android APK. Wallet credit happens only after server-side gateway verification and is idempotent.

## Rocket / DBBL
DBBL's public web presence confirms Rocket is a DBBL mobile-banking product and DBBL operates e-commerce/payment-gateway infrastructure; DBBL also publishes an e-commerce web-service endpoint. However, the exact Rocket merchant API request/response contract is not exposed in the public pages used here. Therefore this project includes a **server-side Rocket adapter**, but it intentionally does not invent DBBL endpoint URLs, credentials, signatures, or field names.

Before production, obtain the Rocket/DBBL merchant gateway integration pack from DBBL and fill `ROCKET_CREATE_URL`, `ROCKET_VERIFY_URL`, `ROCKET_MERCHANT_ID`, `ROCKET_API_KEY`, and the approved HTTPS callback URL. The adapter sends a server-side create request, redirects the customer to the returned checkout URL, then verifies the payment server-to-server before crediting `wallet_ledger`. Do not use a personal Rocket number as a substitute for merchant gateway credentials.

Endpoints:
- `POST /v1/payments/rocket/create`
- `GET /v1/payments/rocket/callback`
- `POST /v1/payments/rocket/verify`

## Nagad
The Nagad flow is server-side: initialize -> decrypt the payment reference/challenge -> complete checkout -> redirect the customer to Nagad -> receive callback -> verify with Nagad -> credit the wallet ledger. Nagad production requires merchant onboarding, credentials/keys, and callback/server-IP whitelisting; do not put private keys in the Android app.

Nagad configuration is intentionally left blank in `.env.example`. Obtain the exact production base URL, merchant ID/number, merchant private key, Nagad PG public key, and approved callback URL from Nagad. Sandbox should be used before production.

## Security
- Android sends only a Firebase ID token and amount/order data to this backend.
- `payment_orders.ownerUid` is server-assigned.
- Client cannot mark an order paid or write the financial ledger.
- Callback data is not trusted as proof of payment; the backend calls Nagad verification first and checks the verified amount against the stored order amount.
- Ledger writes are idempotent to prevent duplicate wallet credits.
- Keep all merchant credentials/private keys in the hosting provider's secret store.
- Deploy behind HTTPS.

## Endpoints
- `POST /v1/payments/bkash/create`
- `POST /v1/payments/bkash/execute`
- `POST /v1/payments/nagad/create`
- `GET /v1/payments/nagad/callback`
- `POST /v1/payments/nagad/verify`
