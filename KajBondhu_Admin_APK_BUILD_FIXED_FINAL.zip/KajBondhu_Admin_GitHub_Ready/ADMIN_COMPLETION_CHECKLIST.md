# কাজবন্ধু Admin App — Online Completion Checklist

## ঠিক করা হয়েছে
- User App থেকে সম্পূর্ণ আলাদা applicationId: `com.aistudio.kajbondhu.admin`
- Launcher activity package ঠিক করা হয়েছে
- পুরনো ভুল/অপ্রয়োজনীয় User MainActivity source সরানো হয়েছে
- Google Login
- Firebase UID ভিত্তিক Admin allow-list
- `admins/{uid}.enabled == true` ছাড়া প্রবেশ নিষিদ্ধ
- Users/Workers/Jobs realtime dashboard
- Live counts: total/pending/accepted/in-progress/completed
- Worker এবং Job delete-এর আগে confirmation
- Firestore rules-এ admin-only privileged access

## Firebase-এ করতে হবে
1. User App ও Admin App একই Firebase project ব্যবহার করতে পারেন।
2. Admin Google account দিয়ে একবার Firebase Authentication-এ login করুন।
3. সেই account-এর Firebase UID কপি করুন।
4. Firestore-এ `admins/{UID}` document তৈরি করুন:
   - `enabled: true`
   - `role: "ADMIN"`
5. Admin App-এ Google Login করুন।

## গুরুত্বপূর্ণ
Admin App-এর `google-services.json`-এ `com.aistudio.kajbondhu.admin` package configuration থাকতে হবে। বর্তমান ZIP-এ সেটি রাখা হয়েছে।

## Build
Local verification environment-এ Gradle wrapper JAR না থাকায় এখানে APK compile করা হয়নি। Android Studio/Google AI Studio-তে Gradle Sync চালিয়ে build করুন।
