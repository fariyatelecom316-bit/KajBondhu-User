package com.kajbondhu.admin.auth

import android.app.Activity
import android.app.Application
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aistudio.kajbondhu.admin.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

 data class AdminAuthState(
    val loading: Boolean = false,
    val authenticated: Boolean = false,
    val isAdmin: Boolean = false,
    val uid: String? = null,
    val name: String = "",
    val email: String = "",
    val error: String? = null
 )

class AdminAuthViewModel(app: Application) : AndroidViewModel(app) {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val _state = MutableStateFlow(AdminAuthState())
    val state: StateFlow<AdminAuthState> = _state.asStateFlow()

    init {
        val u = auth.currentUser
        if (u != null) checkAdmin(u.uid, u.displayName ?: "", u.email ?: "")
    }

    fun signIn(activity: Activity) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val option = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(activity.getString(R.string.default_web_client_id))
                    .setAutoSelectEnabled(false).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                val result = CredentialManager.create(activity).getCredential(activity, request)
                val c = result.credential
                if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val g = GoogleIdTokenCredential.createFrom(c.data)
                    auth.signInWithCredential(GoogleAuthProvider.getCredential(g.idToken, null))
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val u = task.result?.user ?: auth.currentUser
                                if (u != null) checkAdmin(u.uid, u.displayName ?: "", u.email ?: "")
                            } else _state.value = _state.value.copy(loading = false, error = task.exception?.localizedMessage ?: "Google লগইন ব্যর্থ")
                        }
                } else _state.value = _state.value.copy(loading = false, error = "Google credential পাওয়া যায়নি")
            } catch (e: Exception) { _state.value = _state.value.copy(loading = false, error = e.localizedMessage ?: "লগইন ব্যর্থ") }
        }
    }

    private fun checkAdmin(uid: String, name: String, email: String) {
        db.collection("admins").document(uid).get().addOnCompleteListener { t ->
            val ok = t.isSuccessful && t.result?.exists() == true && (t.result?.getBoolean("enabled") == true)
            if (ok) _state.value = AdminAuthState(false, true, true, uid, name, email)
            else {
                auth.signOut()
                _state.value = AdminAuthState(false, false, false, null, "", "", "এই Google Account-এর Admin অনুমতি নেই।")
            }
        }
    }

    fun signOut() { auth.signOut(); _state.value = AdminAuthState() }
}
