package com.kajbondhu.admin.ui

import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AdminStats(
    val users: Int = 0,
    val workers: Int = 0,
    val jobs: Int = 0,
    val pending: Int = 0,
    val accepted: Int = 0,
    val inProgress: Int = 0,
    val completed: Int = 0
)
data class AdminRow(val id: String, val title: String, val subtitle: String, val status: String = "")

class AdminViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()
    private var usersListener: ListenerRegistration? = null
    private var workersListener: ListenerRegistration? = null
    private var jobsListener: ListenerRegistration? = null

    private val _stats = MutableStateFlow(AdminStats())
    val stats: StateFlow<AdminStats> = _stats.asStateFlow()
    private val _workers = MutableStateFlow<List<AdminRow>>(emptyList())
    val workers: StateFlow<List<AdminRow>> = _workers.asStateFlow()
    private val _jobs = MutableStateFlow<List<AdminRow>>(emptyList())
    val jobs: StateFlow<List<AdminRow>> = _jobs.asStateFlow()
    private val _users = MutableStateFlow<List<AdminRow>>(emptyList())
    val users: StateFlow<List<AdminRow>> = _users.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init { startListeners() }

    fun startListeners() {
        stopListeners()
        usersListener = db.collection("users").addSnapshotListener { snap, e ->
            if (e != null) { _error.value = e.localizedMessage; return@addSnapshotListener }
            _users.value = snap?.documents.orEmpty().map { d ->
                val name = d.getString("name") ?: d.getString("displayName") ?: "ব্যবহারকারী"
                val contact = d.getString("email") ?: d.getString("phone") ?: d.getString("phoneNumber") ?: ""
                AdminRow(d.id, name, contact)
            }
            recalc()
        }
        workersListener = db.collection("workers").addSnapshotListener { snap, e ->
            if (e != null) { _error.value = e.localizedMessage; return@addSnapshotListener }
            _workers.value = snap?.documents.orEmpty().map { d ->
                val name = d.getString("nameBn") ?: d.getString("name") ?: "নাম নেই"
                val category = d.getString("categoryTitleBn") ?: d.getString("categoryName") ?: ""
                val verified = if (d.getBoolean("isVerified") == true) "ভেরিফায়েড" else "যাচাই বাকি"
                AdminRow(d.id, name, category, verified)
            }
            recalc()
        }
        jobsListener = db.collection("job_posts").addSnapshotListener { snap, e ->
            if (e != null) { _error.value = e.localizedMessage; return@addSnapshotListener }
            _jobs.value = snap?.documents.orEmpty().map { d ->
                AdminRow(
                    d.id,
                    d.getString("title") ?: "কাজ",
                    d.getString("address") ?: d.getString("area") ?: "",
                    d.getString("status") ?: "PENDING"
                )
            }
            recalc()
        }
    }

    private fun recalc() {
        val statuses = _jobs.value.map { it.status.uppercase() }
        _stats.value = AdminStats(
            users = _users.value.size,
            workers = _workers.value.size,
            jobs = _jobs.value.size,
            pending = statuses.count { it == "PENDING" },
            accepted = statuses.count { it == "ACCEPTED" },
            inProgress = statuses.count { it == "IN_PROGRESS" },
            completed = statuses.count { it == "COMPLETED" }
        )
    }

    fun refresh() = startListeners()

    fun setWorkerVerified(id: String, verified: Boolean) {
        db.collection("workers").document(id).update("isVerified", verified)
            .addOnFailureListener { _error.value = it.localizedMessage }
    }

    fun deleteWorker(id: String) {
        db.collection("workers").document(id).delete().addOnFailureListener { _error.value = it.localizedMessage }
    }

    fun setJobStatus(id: String, status: String) {
        db.collection("job_posts").document(id).update("status", status)
            .addOnFailureListener { _error.value = it.localizedMessage }
    }

    fun deleteJob(id: String) {
        db.collection("job_posts").document(id).delete().addOnFailureListener { _error.value = it.localizedMessage }
    }

    override fun onCleared() {
        stopListeners()
        super.onCleared()
    }

    private fun stopListeners() {
        usersListener?.remove(); usersListener = null
        workersListener?.remove(); workersListener = null
        jobsListener?.remove(); jobsListener = null
    }
}
