package com.kajbondhu.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.kajbondhu.admin.auth.AdminAuthViewModel
import com.kajbondhu.admin.ui.AdminRow
import com.kajbondhu.admin.ui.AdminStats
import com.kajbondhu.admin.ui.AdminViewModel

class MainActivity : ComponentActivity() {
    private val auth: AdminAuthViewModel by viewModels()
    private val vm: AdminViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyApplicationTheme { AdminApp(auth, vm, this) } }
    }
}

@Composable
fun AdminApp(auth: AdminAuthViewModel, vm: AdminViewModel, activity: ComponentActivity) {
    val a by auth.state.collectAsState()
    if (!a.authenticated || !a.isAdmin) {
        AdminLogin(a.loading, a.error) { auth.signIn(activity) }
    } else {
        AdminHome(a.name, a.email, vm) { auth.signOut() }
    }
}

@Composable
fun AdminLogin(loading: Boolean, error: String?, onLogin: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("কাজবন্ধু Admin", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(10.dp))
        Text("শুধু অনুমোদিত Admin Account দিয়ে প্রবেশ করুন।")
        Spacer(Modifier.height(24.dp))
        Button(onClick = onLogin, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.AccountCircle, null)
            Spacer(Modifier.width(8.dp))
            Text(if (loading) "লগইন হচ্ছে…" else "Google দিয়ে Admin Login")
        }
        if (error != null) {
            Spacer(Modifier.height(16.dp))
            Text(error, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
fun AdminHome(name: String, email: String, vm: AdminViewModel, onLogout: () -> Unit) {
    val s by vm.stats.collectAsState()
    val w by vm.workers.collectAsState()
    val j by vm.jobs.collectAsState()
    val u by vm.users.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("কাজবন্ধু Admin") },
                actions = {
                    IconButton(onClick = vm::refresh) { Icon(Icons.Default.Refresh, "রিফ্রেশ") }
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "লগআউট") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                val labels = listOf("ড্যাশবোর্ড", "কারিগর", "কাজ", "ইউজার")
                val icons = listOf(Icons.Default.Dashboard, Icons.Default.Build, Icons.Default.Work, Icons.Default.Person)
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], null) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> Dashboard(s, name, email)
                1 -> WorkerRows(w, vm)
                2 -> JobRows(j, vm)
                else -> Rows("ইউজার তালিকা", u, null)
            }
        }
    }
}

@Composable
fun WorkerRows(rows: List<AdminRow>, vm: AdminViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("কারিগর তালিকা", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        LazyColumn {
            items(rows, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(r.title, style = MaterialTheme.typography.titleMedium); Text(r.subtitle); Text(r.status) }
                        Column {
                            TextButton(onClick = { vm.setWorkerVerified(r.id, r.status != "ভেরিফায়েড") }) { Text(if (r.status == "ভেরিফায়েড") "Unverify" else "Verify") }
                            TextButton(onClick = { vm.deleteWorker(r.id) }) { Text("ডিলিট") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JobRows(rows: List<AdminRow>, vm: AdminViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("কাজের তালিকা", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        LazyColumn {
            items(rows, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(r.title, style = MaterialTheme.typography.titleMedium)
                        Text(r.subtitle)
                        Text("স্ট্যাটাস: ${r.status}")
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("PENDING", "ACCEPTED", "IN_PROGRESS", "COMPLETED", "CANCELLED").forEach { status ->
                                TextButton(onClick = { vm.setJobStatus(r.id, status) }) { Text(status, fontSize = 10.sp) }
                            }
                        }
                        TextButton(onClick = { vm.deleteJob(r.id) }) { Text("ডিলিট") }
                    }
                }
            }
        }
    }
}

@Composable
fun Dashboard(s: AdminStats, name: String, email: String) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("স্বাগতম, ${name.ifBlank { "Admin" }}", style = MaterialTheme.typography.headlineSmall)
            Text(email)
            Spacer(Modifier.height(18.dp))
        }
        item { Stat("মোট ইউজার", s.users) }
        item { Stat("মোট কারিগর", s.workers) }
        item { Stat("মোট কাজ", s.jobs) }
        item { Stat("Pending কাজ", s.pending) }
        item { Stat("Accepted কাজ", s.accepted) }
        item { Stat("In Progress", s.inProgress) }
        item { Stat("Completed কাজ", s.completed) }
    }
}

@Composable
fun Stat(label: String, value: Int) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(value.toString(), style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
fun Rows(title: String, rows: List<AdminRow>, onDelete: ((String) -> Unit)?) {
    var pendingDelete by remember { mutableStateOf<AdminRow?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        if (rows.isEmpty()) {
            Text("কোনো তথ্য পাওয়া যায়নি।", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn {
            items(rows, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title, style = MaterialTheme.typography.titleMedium)
                            if (r.subtitle.isNotBlank()) Text(r.subtitle)
                            if (r.status.isNotBlank()) Text("স্ট্যাটাস: ${r.status}")
                        }
                        if (onDelete != null) {
                            IconButton(onClick = { pendingDelete = r }) { Icon(Icons.Default.Delete, "ডিলিট") }
                        }
                    }
                }
            }
        }
    }
    pendingDelete?.let { row ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("ডিলিট নিশ্চিত করুন") },
            text = { Text("“${row.title}” স্থায়ীভাবে মুছে ফেলতে চান?") },
            confirmButton = { TextButton(onClick = { onDelete?.invoke(row.id); pendingDelete = null }) { Text("ডিলিট") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("বাতিল") } }
        )
    }
}
