# কাজবন্ধু Admin — আলাদা Admin App

এটি মূল User App থেকে আলাদা Android application।

## Admin access security
Admin login-এর পর `admins/{Firebase UID}` document না থাকলে প্রবেশ বন্ধ হবে। Document উদাহরণ:

`admins/<UID>`
```json
{"enabled": true, "role": "admin"}
```

এই document Firebase Console/secure server থেকে তৈরি করতে হবে। Admin app নিজে admin তৈরি করতে পারে না।

## Firebase setup (প্রথমবার)
Admin app-এর package name:
`com.aistudio.kajbondhu.admin`

Firebase Console → Project settings → Your apps → Add app → Android → এই package name দিন এবং Admin app-এর SHA-1/SHA-256 যোগ করুন। তারপর নতুন `google-services.json` ডাউনলোড করে `app/google-services.json`-এ বসান।

বর্তমান ZIP-এ project-এর বিদ্যমান Firebase config কপি করা আছে, কিন্তু নতুন Android package-এর জন্য Firebase Console-এ registration করা বাধ্যতামূলক।

## Admin features
- Dashboard statistics
- User list
- Worker list
- Job list
- Worker/Job delete moderation
- Realtime backend data refresh
- Admin-only Firestore rules

## গুরুত্বপূর্ণ
`admins` collection client দিয়ে write করা নিষিদ্ধ। Admin privilege কখনও APK-তে hard-code করা হয়নি।
