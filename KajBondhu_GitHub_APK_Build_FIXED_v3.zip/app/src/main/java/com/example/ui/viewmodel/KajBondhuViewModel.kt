package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiChatMessage
import com.example.data.ai.GeminiAiService
import com.example.data.local.KajBondhuDatabase
import com.example.data.local.SeedData
import com.example.data.model.ChatMessageEntity
import com.example.data.model.JobRequestEntity
import com.example.data.model.ServiceCategory
import com.example.data.model.WalletTransactionEntity
import com.example.data.model.WorkerEntity
import com.example.data.repository.FirestoreSyncRepository
import com.example.data.repository.KajBondhuRepository
import com.example.data.repository.PaymentGatewayRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavTab {
    HOME,
    WORKERS,
    BOOKINGS,
    WALLET,
    AI_CHAT,
    PROFILE
}

enum class UserMode {
    CLIENT,
    WORKER
}

class KajBondhuViewModel(application: Application) : AndroidViewModel(application) {
    private val db = KajBondhuDatabase.getDatabase(application)
    private val repository = KajBondhuRepository(db)
    private val firestoreRepository = FirestoreSyncRepository()
    private val geminiService = GeminiAiService()
    private val paymentRepository = PaymentGatewayRepository(application)

    // User & Session state
    private val prefs = application.getSharedPreferences("kajbondhu_prefs", Application.MODE_PRIVATE)
    private val _userMode = MutableStateFlow(
        runCatching { UserMode.valueOf(prefs.getString("user_mode", UserMode.CLIENT.name) ?: UserMode.CLIENT.name) }.getOrDefault(UserMode.CLIENT)
    )
    val userMode: StateFlow<UserMode> = _userMode.asStateFlow()

    private val _currentLocation = MutableStateFlow("মিরপুর, ঢাকা")
    val currentLocation: StateFlow<String> = _currentLocation.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<String?>(null)
    val selectedCategoryId: StateFlow<String?> = _selectedCategoryId.asStateFlow()

    private val _workerSearchQuery = MutableStateFlow("")
    val workerSearchQuery: StateFlow<String> = _workerSearchQuery.asStateFlow()

    // Service Categories
    private val _categories = MutableStateFlow(repository.getCategories())
    val categories: StateFlow<List<ServiceCategory>> = _categories.asStateFlow()

    // Workers Stream from Room
    val allWorkers: StateFlow<List<WorkerEntity>> = repository.getAllWorkers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredWorkers: StateFlow<List<WorkerEntity>> = combine(
        allWorkers,
        _selectedCategoryId,
        _workerSearchQuery
    ) { workersList, catId, query ->
        var list = workersList
        if (catId != null) {
            list = list.filter { it.categoryId == catId }
        }
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.nameBn.lowercase().contains(q) ||
                it.nameEn.lowercase().contains(q) ||
                it.categoryTitleBn.lowercase().contains(q) ||
                it.area.lowercase().contains(q) ||
                it.skillsBn.lowercase().contains(q)
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Jobs Stream from Room
    val jobs: StateFlow<List<JobRequestEntity>> = repository.getAllJobs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Wallet Transactions Stream from Room
    private val _walletTransactions = MutableStateFlow<List<WalletTransactionEntity>>(emptyList())
    val walletTransactions: StateFlow<List<WalletTransactionEntity>> = _walletTransactions.asStateFlow()

    // Currently logged-in or viewed Worker profile
    private val _authenticatedUid = MutableStateFlow<String?>(null)

    private val _currentWorkerProfile = MutableStateFlow<WorkerEntity?>(null)
    val currentWorkerProfile: StateFlow<WorkerEntity?> = _currentWorkerProfile.asStateFlow()

    // Gemini AI Chat state
    private val _aiMessages = MutableStateFlow<List<AiChatMessage>>(
        listOf(
            AiChatMessage(
                isUser = false,
                message = "আসসালামু আলাইকুম! আমি কাজবন্ধু এআই সহকারী। আপনার বাসার যেকোনো ইলেকট্রিক, প্লাম্বিং, এসি বা ক্লিনিং সেবার পরামর্শ বা খরচের অনুমানের জন্য প্রশ্ন করতে পারেন।",
                userRole = "CLIENT"
            )
        )
    )
    val aiMessages: StateFlow<List<AiChatMessage>> = _aiMessages.asStateFlow()

    private val _isAiGenerating = MutableStateFlow(false)
    val isAiGenerating: StateFlow<Boolean> = _isAiGenerating.asStateFlow()

    // Active Chat dialog messages
    private val _currentJobChatMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val currentJobChatMessages: StateFlow<List<ChatMessageEntity>> = _currentJobChatMessages.asStateFlow()
    private var chatCollectionJob: Job? = null
    private var syncJob: Job? = null
    private var workersListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var jobsListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var chatListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var walletLedgerListener: com.google.firebase.firestore.ListenerRegistration? = null
    private val _paymentMessage = MutableStateFlow<String?>(null)
    val paymentMessage: StateFlow<String?> = _paymentMessage.asStateFlow()
    private var pendingBkash: Pair<String, String>? = null

    init {
        viewModelScope.launch { repository.ensureSeeded() }
    }

    /**
     * Synchronize current worker profile strictly with authenticated user UID.
     * Never assigns a random or first worker as the current user.
     */
    fun syncWorkerWithAuth(userUid: String?, userPhone: String?, displayName: String = "", email: String = "") {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            _authenticatedUid.value = userUid
            if (!userUid.isNullOrBlank()) {
                firestoreRepository.syncUserProfile(
                    userId = userUid,
                    phone = userPhone.orEmpty(),
                    name = displayName,
                    role = _userMode.value.name,
                    email = email,
                    district = "ঢাকা",
                    area = _currentLocation.value
                )
            }
            workersListener?.remove(); jobsListener?.remove(); chatListener?.remove(); walletLedgerListener?.remove()
            if (userUid.isNullOrBlank()) {
                _currentWorkerProfile.value = null
                _walletTransactions.value = emptyList()
                return@launch
            }
            workersListener = firestoreRepository.listenWorkers(onResult = { remote ->
                viewModelScope.launch { remote.forEach { repository.insertWorker(it) } }
            })
            jobsListener = firestoreRepository.listenJobs(onResult = { remote ->
                viewModelScope.launch { remote.filter { it.id > 0 }.forEach { repository.postJob(it) } }
            })
            launch {
                repository.getWalletTransactions(userUid).collect { _walletTransactions.value = it }
            }
            walletLedgerListener = firestoreRepository.listenWalletLedger(userUid, onResult = { remote ->
                viewModelScope.launch {
                    repository.insertWalletTransactions(remote)
                    _walletTransactions.value = remote + _walletTransactions.value.filter { it.externalId == null }
                }
            })
            allWorkers.collect { list ->
                // A profile belongs to a user only through its authenticated Firebase UID.
                // Phone-number matching is intentionally not used because it could expose
                // another user's profile when phone data is duplicated or stale.
                _currentWorkerProfile.value = list.firstOrNull { it.ownerUid == userUid }
            }
        }
    }

    fun setUserMode(mode: UserMode) {
        _userMode.value = mode
        prefs.edit().putString("user_mode", mode.name).apply()
    }

    fun setCurrentLocation(loc: String) {
        _currentLocation.value = loc
    }

    fun setSelectedCategoryId(id: String?) {
        _selectedCategoryId.value = id
    }

    fun setWorkerSearchQuery(query: String) {
        _workerSearchQuery.value = query
    }

    fun postNewJob(
        title: String,
        categoryId: String,
        description: String,
        address: String,
        budget: Int,
        isUrgent: Boolean,
        scheduledDate: String,
        scheduledTime: String,
        clientName: String = "গ্রাহক",
        clientPhone: String = ""
    ) {
        viewModelScope.launch {
            val ownerUid = _authenticatedUid.value ?: return@launch
            val cat = categories.value.find { it.id == categoryId }
            val catTitle = cat?.titleBn ?: "সাধারণ কাজ"
            val job = JobRequestEntity(
                id = System.currentTimeMillis(),
                clientName = clientName,
                clientPhone = clientPhone,
                title = title,
                categoryId = categoryId,
                categoryTitleBn = catTitle,
                description = description,
                address = address,
                area = address.split(",").firstOrNull()?.trim() ?: _currentLocation.value,
                budget = budget,
                isUrgent = isUrgent,
                scheduledDate = scheduledDate,
                scheduledTime = scheduledTime,
                status = "PENDING",
                ownerUid = ownerUid
            )
            val generatedId = repository.postJob(job)
            val jobWithId = job.copy(id = generatedId)
            firestoreRepository.syncJobToFirestore(jobWithId)
        }
    }

    fun bookWorkerDirect(
        worker: WorkerEntity,
        title: String,
        description: String,
        address: String,
        budget: Int,
        clientName: String = "গ্রাহক",
        clientPhone: String = ""
    ) {
        viewModelScope.launch {
            val ownerUid = _authenticatedUid.value ?: return@launch
            val job = JobRequestEntity(
                id = System.currentTimeMillis(),
                clientName = clientName,
                clientPhone = clientPhone,
                title = title,
                categoryId = worker.categoryId,
                categoryTitleBn = worker.categoryTitleBn,
                description = description,
                address = address,
                area = address.split(",").firstOrNull()?.trim() ?: _currentLocation.value,
                budget = budget,
                isUrgent = false,
                scheduledDate = "আজকে",
                scheduledTime = "দ্রুততম সময়ে",
                status = "ACCEPTED",
                assignedWorkerId = worker.id,
                assignedWorkerName = worker.nameBn,
                assignedWorkerPhone = worker.phone,
                assignedWorkerUid = worker.ownerUid,
                ownerUid = ownerUid
            )
            val generatedId = repository.postJob(job)
            val jobWithId = job.copy(id = generatedId)
            firestoreRepository.syncJobToFirestore(jobWithId)
        }
    }

    fun updateJobStatus(jobId: Long, newStatus: String) {
        viewModelScope.launch {
            val uid = _authenticatedUid.value ?: return@launch
            val existing = jobs.value.find { it.id == jobId } ?: return@launch
            val allowed = existing.ownerUid == uid || existing.assignedWorkerUid == uid
            if (!allowed) return@launch
            repository.updateJobStatus(jobId, newStatus)
            firestoreRepository.syncJobToFirestore(existing.copy(status = newStatus))
        }
    }

    fun acceptJobAsWorker(job: JobRequestEntity) {
        viewModelScope.launch {
            val workerUid = _authenticatedUid.value ?: return@launch
            if (job.status != "PENDING" || job.assignedWorkerUid != null || job.ownerUid == workerUid) return@launch
            val worker = _currentWorkerProfile.value
            val workerId = worker?.id ?: 1L
            val workerName = worker?.nameBn ?: "কারিগর"
            val workerPhone = worker?.phone ?: ""
            repository.assignWorkerToJob(
                jobId = job.id,
                workerId = workerId,
                workerName = workerName,
                workerPhone = workerPhone,
                workerUid = workerUid
            )
            val updated = job.copy(
                assignedWorkerId = workerId,
                assignedWorkerName = workerName,
                assignedWorkerPhone = workerPhone,
                assignedWorkerUid = workerUid,
                status = "ACCEPTED"
            )
            firestoreRepository.syncJobToFirestore(updated)
        }
    }

    fun submitJobReview(jobId: Long, workerId: Long?, rating: Int, reviewText: String) {
        viewModelScope.launch {
            repository.submitReview(jobId, rating, reviewText)
            val existing = jobs.value.find { it.id == jobId }
            if (existing != null) {
                val updated = existing.copy(ratingGiven = rating, reviewGiven = reviewText)
                firestoreRepository.syncJobToFirestore(updated)
            }
        }
    }

    fun saveWorkerProfile(worker: WorkerEntity, currentUid: String? = null) {
        viewModelScope.launch {
            val uid = currentUid?.trim().orEmpty()
            // No authenticated user = no profile write.
            if (uid.isBlank()) return@launch

            // Existing profiles can ONLY be edited by their original owner.
            // A missing owner is never silently claimed during an edit.
            if (worker.id != 0L && worker.ownerUid?.trim() != uid) {
                return@launch
            }

            val workerWithOwnership = if (worker.id == 0L) {
                worker.copy(ownerUid = uid)
            } else {
                // Preserve the immutable owner UID for existing profiles.
                worker.copy(ownerUid = uid)
            }
            if (workerWithOwnership.id == 0L) {
                val saved = workerWithOwnership.copy(id = System.currentTimeMillis())
                repository.insertWorker(saved)
                _currentWorkerProfile.value = saved
                firestoreRepository.syncWorkerToFirestore(saved)
            } else {
                repository.updateWorker(workerWithOwnership)
                _currentWorkerProfile.value = workerWithOwnership
                firestoreRepository.syncWorkerToFirestore(workerWithOwnership)
            }
        }
    }

    fun addWalletMoney(amount: Int, method: String, onCheckout: (String) -> Unit = {}) {
        if (amount < 10) { _paymentMessage.value = "সর্বনিম্ন ১০ টাকা যোগ করা যাবে।"; return }
        viewModelScope.launch {
            _paymentMessage.value = "পেমেন্ট প্রস্তুত হচ্ছে…"
            val result = paymentRepository.createCheckout(amount, method)
            result.onSuccess { checkout ->
                _paymentMessage.value = null
                if (method.equals("bKash", ignoreCase = true) && checkout.paymentId != null) {
                    pendingBkash = checkout.orderId to checkout.paymentId
                }
                val url = checkout.checkoutUrl
                if (url.isNullOrBlank()) {
                    _paymentMessage.value = "পেমেন্ট অর্ডার তৈরি হয়েছে। গেটওয়ে URL পাওয়া যায়নি; সার্ভার কনফিগারেশন পরীক্ষা করুন।"
                } else onCheckout(url)
            }.onFailure { _paymentMessage.value = it.message ?: "পেমেন্ট শুরু করা যায়নি।" }
        }
    }

    fun withdrawWalletMoney(amount: Int, method: String) {
        _paymentMessage.value = "উইথড্র/ক্যাশ-আউট এখন নিরাপদ server-side payout integration ছাড়া চালু করা হয়নি।"
    }

    fun clearPaymentMessage() { _paymentMessage.value = null }

    fun verifyPendingBkash() {
        val pending = pendingBkash ?: run { _paymentMessage.value = "কোনো pending bKash payment নেই।"; return }
        viewModelScope.launch {
            _paymentMessage.value = "bKash পেমেন্ট যাচাই হচ্ছে…"
            paymentRepository.executeBkash(pending.first, pending.second)
                .onSuccess { paid ->
                    if (paid) { pendingBkash = null; _paymentMessage.value = "bKash পেমেন্ট যাচাই হয়েছে। ওয়ালেট ব্যালেন্স আপডেট হবে।" }
                    else _paymentMessage.value = "পেমেন্ট এখনো সম্পন্ন/যাচাই হয়নি।"
                }.onFailure { _paymentMessage.value = it.message ?: "bKash যাচাই ব্যর্থ হয়েছে।" }
        }
    }

    fun loadChatMessages(jobId: Long) {
        chatListener?.remove()
        chatCollectionJob?.cancel()
        chatCollectionJob = viewModelScope.launch {
            repository.getChatMessages(jobId).collect { msgs -> _currentJobChatMessages.value = msgs }
        }
        chatListener = firestoreRepository.listenChat(jobId, onResult = { msgs ->
            _currentJobChatMessages.value = msgs
            viewModelScope.launch { msgs.forEach { repository.sendChatMessage(jobId, it.senderName, it.isClient, it.messageText, it.senderUid) } }
        })
    }

    fun sendChatMessage(jobId: Long, text: String, isClient: Boolean, senderName: String) {
        viewModelScope.launch {
            val uid = _authenticatedUid.value ?: return@launch
            val timestamp = System.currentTimeMillis()
            val localId = repository.sendChatMessage(jobId, senderName, isClient, text, uid, timestamp)
            // The verified UID and the real local message ID are stored in Firestore.
            firestoreRepository.syncChatMessage(jobId, ChatMessageEntity(id = localId, jobId = jobId, senderName = senderName, isClient = isClient, senderUid = uid, messageText = text, timestamp = timestamp))
        }
    }

    fun sendAiChatMessage(prompt: String) {
        val role = if (_userMode.value == UserMode.WORKER) "WORKER" else "CLIENT"
        val userMsg = AiChatMessage(
            isUser = true,
            message = prompt,
            userRole = role
        )
        _aiMessages.value = _aiMessages.value + userMsg
        _isAiGenerating.value = true

        viewModelScope.launch {
            try {
                val response = geminiService.sendMessage(
                    history = _aiMessages.value,
                    userMessage = prompt,
                    userRole = role
                )
                val modelMsg = AiChatMessage(
                    isUser = false,
                    message = response,
                    userRole = role
                )
                _aiMessages.value = _aiMessages.value + modelMsg
            } catch (e: Exception) {
                val errorMsg = AiChatMessage(
                    isUser = false,
                    message = "দুঃখিত, সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।",
                    userRole = role
                )
                _aiMessages.value = _aiMessages.value + errorMsg
            } finally {
                _isAiGenerating.value = false
            }
        }
    }

    fun clearAiChat() {
        _aiMessages.value = listOf(
            AiChatMessage(
                isUser = false,
                message = "চ্যাট মুছে ফেলা হয়েছে। আপনার যেকোনো নতুন প্রশ্ন আমাকে করতে পারেন।",
                userRole = if (_userMode.value == UserMode.WORKER) "WORKER" else "CLIENT"
            )
        )
    }
}
